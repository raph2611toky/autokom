#!/usr/bin/env python3
"""AUTOKOM host execution boundary, JSON over a permissioned Unix socket.

Only the dedicated autokom service account and root can request allowlisted
operations. This process runs outside Django. It never accepts shell commands,
Jenkins URL/path, container mount paths or an arbitrary executable.
"""
from __future__ import annotations

from autokom_nginx_bind_policy import https_listens, tls_detected, addresses as https_bind_addresses, BindPolicyError

import hashlib
import fcntl
import http.client
import secrets
import ipaddress
import json
import logging
import os
from pathlib import Path
import pwd
import re
import shutil
import socket
import ssl
import socketserver
import stat
import struct
import subprocess
import tempfile
import time
from urllib.parse import quote, urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError, URLError
import base64
import urllib.request
import threading
import autokom_internal_ingress as ingress
from autokom_customer_diagnostics import capture as capture_customer_diagnostics, read as read_customer_diagnostics

logger = logging.getLogger('autokom.runtime.broker')
SOCKET = Path('/run/autokom/platform-control.sock')
STATE = Path('/var/lib/autokom/client-runtime')
IMAGES = Path('/var/lib/autokom/build-artifacts')
PROXY = Path('/etc/nginx/sites-available')
ENABLED = Path('/etc/nginx/sites-enabled')
WEBROOT = Path('/var/www/autokom-acme')
CLOUDFLARE_CONFIG = Path('/etc/autokom/secrets/cloudflare-dns.env')
RUNTIME_CONFIG = Path('/etc/autokom/secrets/runtime.env')
UUID = re.compile(r'^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$')
HOSTNAME = re.compile(r'^(?=.{4,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$')
KEY = re.compile(r'^[A-Za-z_][A-Za-z0-9_]{0,127}$')
MAX_REQUEST = 512 * 1024
PREPROD = os.getenv('AUTOKOM_BROKER_PROFILE') == 'preprod'
SERVICE_USER = 'autokom-preprod' if PREPROD else 'autokom'
# Only the staging unit opts in. Keep production's defaults intact.
if PREPROD:
    SOCKET = Path('/run/autokom-preprod/platform-control.sock')
    STATE = Path('/var/lib/autokom-preprod/client-runtime')
    IMAGES = Path('/var/lib/autokom-preprod/build-artifacts')
    RUNTIME_CONFIG = Path('/etc/autokom-preprod/runtime.env')
    CLOUDFLARE_CONFIG = Path('/etc/autokom-preprod/cloudflare-dns.env')
NGINX_LOCK = Path('/var/lib/autokom/client-runtime/.deploy.lock')
DNS_COMMENT = 'AUTOKOM preprod managed A record' if PREPROD else 'AUTOKOM managed A record'


class BrokerError(Exception):
    pass

def valid_id(value):
    if not isinstance(value, str) or not UUID.fullmatch(value):
        raise BrokerError('Identifiant AUTOKOM invalide.')
    return value

def valid_hostname(value):
    if not isinstance(value, str) or not HOSTNAME.fullmatch(value) or value.endswith(('.local','.invalid','.test','.example')):
        raise BrokerError('Nom DNS public invalide.')
    return value

def _system_component(argv):
    """Safe, bounded classification; never include user-controlled arguments."""
    name = Path(argv[0]).name if argv else ''
    return name if name in ('nginx', 'certbot', 'dig', 'systemctl', 'docker') else 'runtime'


def run(argv, *, timeout=30, input=None, max_output=16000, pass_fds=()):
    if not isinstance(argv, list) or any(not isinstance(v,str) for v in argv):
        raise BrokerError('Arguments système non autorisés.')
    try:
        p = subprocess.run(argv, input=input, capture_output=True, text=True, timeout=timeout, check=False, pass_fds=pass_fds,
                           env={'PATH':'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin','LANG':'C.UTF-8'})
    except (OSError, subprocess.TimeoutExpired) as exc:
        logger.warning('AUTOKOM_SYSTEM_FAILURE component=%s reason=execution_unavailable',
                       _system_component(argv))
        raise BrokerError('AUTOKOM_SYSTEM_UNAVAILABLE: Action système indisponible ou expirée.') from exc
    if p.returncode:
        # Never log argv, stdout, stderr: commands can contain client secrets.
        component = _system_component(argv)
        logger.warning('AUTOKOM_SYSTEM_FAILURE component=%s exit_status=%d',
                       component, p.returncode)
        raise BrokerError('AUTOKOM_'+component.upper()+'_COMMAND_FAILED: Échec de commande contrôlée.')
    return p.stdout[:max_output]

def jenkins_config():
    # runtime.env is the protected source of truth, including after a token rotation.
    # Do not continue using credentials cached in a long-running systemd process.
    configuration = _runtime_dns_env()
    url = configuration.get('AUTOKOM_JENKINS_URL','').rstrip('/')
    parts = urlsplit(url)
    if parts.scheme != 'https' and not (parts.scheme=='http' and parts.hostname in ('127.0.0.1','localhost')):
        raise BrokerError('Jenkins doit utiliser HTTPS ou loopback.')
    if not parts.hostname or parts.username or parts.password or parts.query or parts.fragment or parts.path not in ('','/'):
        raise BrokerError('Jenkins non configuré.')
    job = configuration.get('AUTOKOM_JENKINS_JOB','autokom-client-deploy')
    if (PREPROD and job != 'autokom-preprod-client-deploy') or not re.fullmatch(r'[\w.-]{1,100}',job):
        raise BrokerError('Job Jenkins invalide.')
    user, token = configuration.get('AUTOKOM_JENKINS_USER',''), configuration.get('AUTOKOM_JENKINS_API_TOKEN','')
    if not user or not token:
        raise BrokerError('Identifiants du compte Jenkins de service absents.')
    return url, '/job/' + quote(job,safe=''), user, token

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        return None

def jenkins_http(method, path, data=None):
    url, job, user, token = jenkins_config()
    if not path.startswith('/') or '//' in path or '..' in path:
        raise BrokerError('Chemin Jenkins refusé.')
    auth = base64.b64encode(f'{user}:{token}'.encode()).decode()
    body = None if data is None else urlencode(data).encode()
    req = Request(url+path, data=body, method=method, headers={'Authorization':'Basic '+auth,
                  'Accept':'application/json','Content-Type':'application/x-www-form-urlencoded'})
    try:
        with build_opener(NoRedirect()).open(req,timeout=18) as response:
            result = response.read(65536)
            return response.status,dict(response.headers),result
    except HTTPError as exc:
        # Only 404 is used to detect a missing job; do not expose full HTTP body.
        return exc.code,dict(exc.headers),b''
    except (URLError, TimeoutError, OSError) as exc:
        raise BrokerError('Jenkins injoignable.') from exc

def _isolated_agent_available():
    """Fail closed before queueing work if the dedicated non-controller agent is offline.

    Read-only Jenkins API. No customer-provided node names and no token in logs.
    """
    path = '/computer/api/json?tree=computer%5BdisplayName,offline,temporarilyOffline,numExecutors,assignedLabels%5Bname%5D%5D'
    code, _, body = jenkins_http('GET', path)
    if code != 200:
        raise BrokerError('Impossible de vérifier les agents de construction Jenkins.')
    try:
        computers = json.loads(body).get('computer', [])
    except (ValueError, TypeError):
        raise BrokerError('État des agents Jenkins illisible.')
    if not isinstance(computers, list):
        raise BrokerError('Liste des agents Jenkins invalide.')
    for computer in computers:
        if not isinstance(computer, dict):
            continue
        name = computer.get('displayName', '')
        # NEVER schedule untrusted customer code on Jenkins' built-in controller.
        if name in ('Built-In Node', 'Jenkins', 'master', ''):
            continue
        labels = {label.get('name') for label in (computer.get('assignedLabels') or [])
                  if isinstance(label, dict)}
        if ('autokom-isolated' in labels and computer.get('offline') is False
                and computer.get('temporarilyOffline') is not True
                and type(computer.get('numExecutors')) is int
                and computer['numExecutors'] >= 1):
            return True
    raise BrokerError('Agent de construction isolé indisponible. Aucune exécution envoyée en file.')


def jenkins_action(action, params):
    _,job,_,_ = jenkins_config()
    if action == 'jenkins.dispatch':
        rid = valid_id(params.get('run_id'))
        ingress.preflight(run, PROXY, ENABLED)  # fail before an unnecessary Jenkins build
        _isolated_agent_available()
        status,headers,_ = jenkins_http('POST',job+'/buildWithParameters',{'AUTOKOM_RUN_ID':rid})
        if status not in (200,201,202):raise BrokerError('Jenkins a refusé le déploiement.')
        location = headers.get('Location','')
        m = re.search(r'/queue/item/(\d+)/?$',location)
        if not m:raise BrokerError('Jenkins ne retourne pas de numéro de file.')
        return {'external_id':'Q:'+m.group(1)}
    external = params.get('external_id','')
    if not isinstance(external,str) or not re.fullmatch(r'[QB]:[1-9]\d{0,12}',external):
        raise BrokerError('Numéro de build Jenkins invalide.')
    kind,num = external.split(':',1)
    if action == 'jenkins.state':
        path = f'/queue/item/{num}/api/json' if kind=='Q' else f'{job}/{num}/api/json'
        status,_,body=jenkins_http('GET',path)
        if status!=200:raise BrokerError('État Jenkins indisponible.')
        data=json.loads(body)
        if PREPROD and kind=='Q':
            task = data.get('task') or {}
            if task.get('name') != 'autokom-preprod-client-deploy':
                raise BrokerError('Élément Jenkins hors préproduction.')
        if kind=='Q':
            if data.get('cancelled'):return {'status':'CANCELLED','external_id':external}
            executable=data.get('executable') or {}
            n=executable.get('number')
            return {'status':'RUNNING','external_id':('B:'+str(n)) if type(n)==int and n>0 else external}
        if data.get('building'):return {'status':'RUNNING','external_id':external}
        mapping={'SUCCESS':'SUCCEEDED','FAILURE':'FAILED','UNSTABLE':'FAILED','ABORTED':'CANCELLED','NOT_BUILT':'BLOCKED'}
        if data.get('result') not in mapping:raise BrokerError('État Jenkins non déterminé.')
        return {'status':mapping[data['result']],'external_id':external}
    if action == 'jenkins.console':
        if kind!='B':return {'text':'','offset':int(params.get('offset',0))}
        start=params.get('offset',0)
        if type(start)!=int or start<0 or start>100_000_000:raise BrokerError('Position de log invalide.')
        status,headers,body=jenkins_http('GET',f'{job}/{num}/logText/progressiveText?start={start}')
        if status!=200:raise BrokerError('Logs Jenkins indisponibles.')
        chunk=body[:32000]
        offset=start+len(chunk) if len(body)>len(chunk) else max(start,int(headers.get('X-Text-Size',start)))
        return {'text':chunk.decode('utf-8','replace'),'offset':offset}
    if action == 'jenkins.cancel':
        if PREPROD and kind == 'Q':
            jenkins_action('jenkins.state', params)
        status,_,_=jenkins_http('POST',f'/queue/cancelItem?id={num}' if kind=='Q' else f'{job}/{num}/stop',{})
        if status not in (200,201,202,302):raise BrokerError('Annulation Jenkins refusée.')
        return {'cancel_requested':True}
    raise BrokerError('Action Jenkins non reconnue.')

def _safe_env(values):
    if not isinstance(values,dict) or len(values)>100:raise BrokerError('Variables trop nombreuses.')
    for key,value in values.items():
        if not isinstance(key,str) or not KEY.fullmatch(key) or key.startswith(('AUTOKOM_', 'DOCKER_')):
            raise BrokerError('Nom de variable réservé ou invalide.')
        if not isinstance(value,str) or len(value)>32768 or '\x00' in value or '\r' in value or '\n' in value:
            raise BrokerError('Valeur de variable refusée (retour ligne non pris en charge).')
    return values

def _docker_loopback_port(container, container_port):
    """Read the port allocated atomically by Docker; never use a scan-then-bind race."""
    name = valid_container_name(container)
    if type(container_port) is not int or not 1 <= container_port <= 65535:
        raise BrokerError('Port interne du service invalide.')
    raw = run(['docker', 'container', 'inspect', name,
               '--format', '{{json .NetworkSettings.Ports}}'], timeout=12, max_output=8192)
    try:
        bindings = json.loads(raw)[f'{container_port}/tcp']
        if not isinstance(bindings, list) or len(bindings) != 1:
            raise ValueError('Binding multiple')
        mapping = bindings[0]
        if mapping['HostIp'] != '127.0.0.1':
            raise ValueError('Non-loopback binding')
        selected = int(mapping['HostPort'])
        if not (1024 <= selected <= 65535):
            raise ValueError('Invalid allocated port')
    except (KeyError, ValueError, TypeError, IndexError, AttributeError):
        raise BrokerError('Publication locale Docker non conforme ; aucun accès public autorisé.')
    return selected


def valid_container_name(name):
    if not isinstance(name, str) or not re.fullmatch(r'autokom-[a-f0-9]{20}', name):
        raise BrokerError('Conteneur AUTOKOM invalide.')
    return name


def _env_file(env,run_id,values):
    base=STATE/env
    base.mkdir(parents=True,exist_ok=True,mode=0o700)
    os.chmod(base,0o700)
    name=base/(run_id+'.env')
    with tempfile.NamedTemporaryFile(mode='w',dir=base,delete=False,prefix='.env-',encoding='utf-8') as fd:
        os.chmod(fd.name,0o600)
        for k,v in _safe_env(values).items():
            fd.write(k+'='+v+'\n')
        tmp=fd.name
    os.replace(tmp,name)
    return name

def _load_state(environment):
    path=STATE/environment/'current.json'
    if not path.exists():return None
    doc=json.loads(path.read_text(encoding='utf-8'))
    if doc.get('environment_id')!=environment:raise BrokerError('État du runtime incohérent.')
    return doc

def _save_state(environment,doc):
    path=STATE/environment/'current.json'
    with tempfile.NamedTemporaryFile('w',dir=path.parent,delete=False,prefix='.state-',encoding='utf-8') as fd:
        os.chmod(fd.name,0o600)
        json.dump(doc,fd)
        fd.write('\n')
        tmp=fd.name
    os.replace(tmp,path)

def _dynamic_preview(params):
    """Run a health/header probe in a disposable, networkless candidate."""
    rid = valid_id(params.get('run_id'))
    port, path = params.get('internal_port'), params.get('healthcheck')
    memory, cpu = params.get('memory_mb'), params.get('cpu_millicores')
    if (type(port) is not int or not 1 <= port <= 65535 or
            not isinstance(path, str) or not re.fullmatch(r'/[A-Za-z0-9/_~.\-]{0,127}', path)
            or path.startswith('//') or type(memory) is not int or not 128 <= memory <= 32768
            or type(cpu) is not int or not 100 <= cpu <= 8000):
        raise BrokerError('AUTOKOM_DYNAMIC_PREVIEW_INVALID')
    # An app bound only to its assigned container IP will require the normal
    # candidate check. No client host, headers, variables or credentials enter here.
    if port < 1024:
        return {'http':0, 'warnings':[]}
    probe_tag = 'docker.io/library/python:3.12-alpine'
    try:
        probe_image = run(['docker','image','inspect',probe_tag,'--format','{{.Id}}'],timeout=8).strip()
    except BrokerError:
        run(['docker','pull',probe_tag],timeout=65)
        probe_image = run(['docker','image','inspect',probe_tag,'--format','{{.Id}}'],timeout=8).strip()
    if not re.fullmatch(r'sha256:[a-f0-9]{64}', probe_image):
        raise BrokerError('AUTOKOM_DYNAMIC_PROBE_IMAGE_INVALID: Image de contrôle indisponible.')
    artifact = IMAGES/(rid+'.tar')
    tag = ('autokom-preprod-local:' if PREPROD else 'autokom-local:') + rid
    fd = os.open(artifact, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or not 1024 <= info.st_size <= 8*1024**3:
            raise BrokerError('AUTOKOM_DYNAMIC_PREVIEW_ARTIFACT_INVALID')
        if shutil.disk_usage(IMAGES).free < max(256*1024**2, info.st_size*2):
            raise BrokerError('AUTOKOM_DISK_LOW')
        run(['docker','load','--input',f'/proc/self/fd/{fd}'],timeout=80,pass_fds=(fd,))
    finally:
        os.close(fd)
    image = run(['docker','image','inspect',tag,'--format','{{.Id}}']).strip()
    if not re.fullmatch(r'sha256:[a-f0-9]{64}', image):
        raise BrokerError('AUTOKOM_DYNAMIC_PREVIEW_ARTIFACT_INVALID')
    name = 'autokom-dast-' + secrets.token_hex(12)
    helper = name + '-probe'
    options = ['--read-only','--cap-drop','ALL','--security-opt','no-new-privileges',
               '--label','com.autokom.dast=temporary',
               '--no-healthcheck','--log-driver','none','--user','10001:10001']
    try:
        run(['docker','run','-d','--name',name,'--network','none',*options,
             '--cpus',str(cpu/1000),'--memory',f'{memory}m','--memory-swap',f'{memory}m',
             '--pids-limit','128','--tmpfs','/tmp:rw,noexec,nosuid,size=128m',image],timeout=18)
        probe = Path(__file__).resolve().with_name('autokom_dynamic_checks.py').read_text(encoding='utf-8')
        # Keep the probe inside a short deadline. No proxy, redirects, exposed
        # port, host namespace, shared filesystem or external destination.
        program = probe + "\nimport json, sys, time\nfor _ in range(6):\n" + (
            " result = inspect_candidate(int(sys.argv[1]), sys.argv[2])\n"
            " if result['http']: break\n time.sleep(1)\nprint(json.dumps(result))\n")
        # Docker cannot join a stopped candidate. A normal runtime with its
        # configured environment is still checked after the Jenkins build.
        try:
            return json.loads(run(['docker','run','--rm','-i','--name',helper,
                '--network','container:'+name,*options,'--pids-limit','32','--memory','64m',
                '--entrypoint','python3',probe_image,'-I','-',str(port),path],
                input=program,timeout=40))
        except BrokerError:
            running = run(['docker','inspect','--format','{{.State.Running}}',name],timeout=5).strip()
            if running == 'false':
                return {'http':0,'warnings':[]}
            raise
    finally:
        for temporary in (helper, name):
            if subprocess.run(['docker','container','inspect',temporary],capture_output=True,timeout=5).returncode == 0:
                run(['docker','rm','-f',temporary],timeout=10)


def _docker_deploy(params):
    """Serialize all Docker reservations to prevent local TCP port collisions."""
    STATE.mkdir(parents=True,exist_ok=True,mode=0o700)
    fd=os.open(NGINX_LOCK if PREPROD else STATE/'.deploy.lock',
               os.O_WRONLY|os.O_CREAT|getattr(os,'O_NOFOLLOW',0),0o600)
    try:
        fcntl.flock(fd,fcntl.LOCK_EX)
        return _docker_deploy_inner(params)
    finally:
        fcntl.flock(fd,fcntl.LOCK_UN)
        os.close(fd)


def _docker_deploy_inner(params):
    environment=valid_id(params.get('environment_id'))
    rid=valid_id(params.get('run_id'))
    cpu=params.get('cpu_millicores')
    mem=params.get('memory_mb')
    storage=params.get('storage_mb')
    port=params.get('internal_port')
    replicas=params.get('replicas')
    health=params.get('healthcheck','/')
    if any(type(n)!=int for n in (cpu,mem,storage,port,replicas)) or not (100<=cpu<=8000 and 128<=mem<=32768 and 128<=storage<=262144 and 1<=port<=65535 and replicas==1):
        raise BrokerError('Ressources invalides ou haute disponibilité non disponible.')
    if not isinstance(health,str) or not health.startswith('/') or len(health)>128 or any(x in health for x in ('?','#','%','\\','\r','\n')):
        raise BrokerError('Healthcheck invalide.')
    ingress.preflight(run, PROXY, ENABLED)
    current=_load_state(environment)
    if current and current.get('run_id')==rid:
        if current.get('ingress_mode') == ingress.MODE and not ingress.probe_relay(current['name'],current['port']):
            raise BrokerError('AUTOKOM_INGRESS_NOT_READY: Relais local interrompu.')
        return {'port':current['port'],'container':current['name'],'idempotent':True}
    restore = params.get('restore')
    if restore is not None:
        if not isinstance(restore, dict):
            raise BrokerError('AUTOKOM_RESTORE_SCOPE_INVALID')
        if (not current or current.get('stack_project_id') != params.get('stack_project_id') or
                current.get('stack_role') != params.get('stack_role') or current.get('run_id') != valid_id(restore.get('expected_current')) or
                (STATE/environment/'previous.json').exists()):
            raise BrokerError('AUTOKOM_RESTORE_ACTIVE_CHANGED: Version active modifiée ou transaction non finalisée.')
    def scoped_id(value):
        return hashlib.sha256(('autokom-preprod:' + value).encode()).hexdigest()[:20] if PREPROD else value.replace('-', '')[:20]
    name='autokom-'+scoped_id(rid)
    already=subprocess.run(['docker','container','inspect',name],capture_output=True,timeout=12)
    if already.returncode==0:
        raise BrokerError('Conteneur de ce run déjà présent hors transaction : réconciliation manuelle requise.')
    prefix = 'autokom-preprod-local:' if PREPROD else 'autokom-local:'
    tag = prefix+rid
    original_rid = valid_id(restore.get('source_run')) if restore is not None else rid
    source_tag = prefix+original_rid
    artifact = IMAGES/(original_rid+'.tar')
    digest = restore.get('image_digest') if restore else None
    if digest and not re.fullmatch(r'sha256:[a-f0-9]{64}', digest):
        raise BrokerError('AUTOKOM_RESTORE_IMAGE_INVALID')
    # Prefer the immutable image ID recorded at publication. For legacy releases
    # without an ID, only the original AUTOKOM artifact is accepted.
    image = ''
    if digest:
        try:
            image = run(['docker','image','inspect',digest,'--format','{{.Id}}'], timeout=12).strip()
        except BrokerError:
            pass
    if not image:
        if artifact.is_symlink() or not artifact.is_file() or not 1024 <= artifact.stat().st_size <= 8*1024**3:
            raise BrokerError('AUTOKOM_RESTORE_IMAGE_MISSING' if restore else 'Archive locale Jenkins introuvable ou non autorisée.')
        if shutil.disk_usage(IMAGES).free < max(256*1024**2, artifact.stat().st_size*2):
            raise BrokerError('AUTOKOM_DISK_LOW: Stockage insuffisant pour importer l’image.')
        fd = os.open(artifact, os.O_RDONLY | getattr(os,'O_NOFOLLOW',0))
        try:
            st=os.fstat(fd)
            if not stat.S_ISREG(st.st_mode) or not 1024 <= st.st_size <= 8*1024**3:
                raise BrokerError('Archive Docker invalide.')
            run(['docker','load','--input',f'/proc/self/fd/{fd}'],timeout=240,pass_fds=(fd,))
        finally:
            os.close(fd)
        image = run(['docker','image','inspect',source_tag,'--format','{{.Id}}']).strip()
    if not re.fullmatch(r'sha256:[a-f0-9]{64}', image) or (digest and image != digest):
        raise BrokerError('AUTOKOM_RESTORE_IMAGE_INVALID')
    if restore:
        run(['docker','tag',image,tag],timeout=20)
    stack_project = params.get('stack_project_id')
    stack_role = params.get('stack_role')
    if stack_project is not None:
        stack_project = valid_id(stack_project)
        if stack_role not in ('frontend', 'backend'):
            raise BrokerError('AUTOKOM_STACK_ROLE_INVALID')
        network = 'autokom-stack-' + scoped_id(stack_project)
    else:
        if stack_role is not None or params.get('stack_backend_environment_id') is not None:
            raise BrokerError('AUTOKOM_STACK_PROJECT_MISSING')
        network = 'autokom-' + scoped_id(environment)
    gateway_port = None
    backend_alias = None
    backend_hostname = None
    if stack_role == 'frontend':
        backend_environment = valid_id(params.get('stack_backend_environment_id'))
        back_state = _load_state(backend_environment)
        if (not back_state or back_state.get('stack_project_id') != stack_project or
                back_state.get('stack_role') != 'backend'):
            raise BrokerError('AUTOKOM_STACK_BACKEND_NOT_READY')
        if not ingress.probe_relay(back_state['name'], back_state['port']):
            raise BrokerError('AUTOKOM_STACK_BACKEND_RELAY_UNAVAILABLE')
        gateway_port = back_state['port']
        backend_alias = 'backend-' + back_state['run_id'].replace('-', '')[:20]
        backend_hostname = valid_hostname(params.get('stack_backend_hostname'))
    inspect=subprocess.run(['docker','network','inspect',network],capture_output=True,text=True,timeout=10)
    if inspect.returncode:
        run(['docker','network','create','--internal','--driver','bridge',network],timeout=30)
    else:
        try:
            networks=json.loads(inspect.stdout)
            if len(networks)!=1 or networks[0].get('Internal') is not True or networks[0].get('Driver')!='bridge':
                raise BrokerError('Réseau existant non privé : aucune connexion Docker.')
        except (ValueError,TypeError,KeyError) as exc:
            raise BrokerError('Réseau Docker existant non vérifiable.') from exc
    variables=_safe_env(params.get('variables') or {})
    if backend_alias:
        if 'BACKEND_INTERNAL_URL' in variables:
            raise BrokerError('AUTOKOM_STACK_RESERVED_VARIABLE')
        variables['BACKEND_INTERNAL_URL'] = 'http://' + backend_alias + ':' + str(back_state.get('internal_port', 8080))
    envfile=_env_file(environment,rid,variables)
    # Customer processes run as UID 10001, without extra capabilities, mounts or Docker socket.
    argv=['docker','run','-d','--name',name,'--network',network]
    if stack_role == 'backend':
        # Immutable alias: the previous backend may remain connected until
        # the two-service cutover is committed. Never use a shared 'backend' alias.
        argv.extend(['--network-alias', 'backend-' + rid.replace('-', '')[:20]])
    argv += [
          '--cpus',str(cpu/1000),'--memory',f'{mem}m','--memory-swap',f'{mem}m',
          '--pids-limit','128','--cap-drop','ALL','--security-opt','no-new-privileges',
          '--read-only','--tmpfs',f'/tmp:rw,noexec,nosuid,size={min(storage,256)}m',
          '--log-driver','json-file','--log-opt','max-size=10m','--log-opt','max-file=3',
          '--user','10001:10001',
           '--env-file',str(envfile),'--restart','unless-stopped',image]
    relay = None
    failure_reason = None
    try:
        try:
            run(argv,timeout=60)
        finally:
            envfile.unlink(missing_ok=True)  # secrets are never kept as host .env files after create
        # Nginx owns the trusted loopback listener. Customer has NO published ports.
        try:
            relay = ingress.create(name, network, port, execute=run, available=PROXY, enabled=ENABLED)
        except ingress.IngressError as exc:
            # Log only validated reason labels, never Docker inspect or customer content.
            failure_reason = exc.reason
            logger.warning('AUTOKOM_INGRESS_REJECT reason=%s role=%s',
                           exc.reason, stack_role if stack_role else 'single')
            raise
        external_port = relay['port']
        from urllib.request import build_opener
        health_opener = build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        deadline=time.monotonic()+75
        while time.monotonic()<deadline:
            try:
                req=Request(f'http://127.0.0.1:{external_port}{health}',headers={'Host':'localhost'})
                with health_opener.open(req,timeout=2) as resp:
                    if 200<=resp.status<400:break
            except Exception:pass
            time.sleep(2)
        else:
            failure_reason = 'healthcheck_no_http'
            raise BrokerError('AUTOKOM_CONTAINER_HEALTHCHECK_FAILED: L’application ne répond pas sur son port interne. '                               'Consulter le diagnostic du run ; ancienne version conservée.')
        previous=_load_state(environment)
        doc={'environment_id':environment,'run_id':rid,'internal_port':port,'port':external_port,
             'name':name,'network':network,'healthcheck':health,**relay,
             'image_digest':image, 'restored_image':bool(restore),
             # Only non-sensitive metadata is mirrored to the private GCP controller.
             # Existing local sites remain functional without the cloud controller.
             'cloud_delivery_requested':params.get('cloud_delivery_requested') is True,
             'high_availability_requested':params.get('ha_requested') is True,
             'variables_present':bool(variables),
             'memory_mb':mem,'cpu_millicores':cpu}
        if stack_project:
            doc['stack_project_id'] = stack_project
            doc['stack_role'] = stack_role
            if gateway_port:
                doc['gateway_port'] = gateway_port
                doc['gateway_hostname'] = backend_hostname
        # Persist previous BEFORE current so a failed snapshot cannot corrupt the active state.
        prior_path=STATE/environment/'previous.json'
        if previous:
            if prior_path.exists():
                raise BrokerError('AUTOKOM_PREVIOUS_PENDING: Ancienne publication non finalisée.')
            with tempfile.NamedTemporaryFile('w',dir=prior_path.parent,delete=False,prefix='.previous-',encoding='utf-8') as fd:
                os.chmod(fd.name,0o600);json.dump(previous,fd);fd.write('\n');tmp=fd.name
            os.replace(tmp,prior_path)
        try:
            _save_state(environment,doc)
        except Exception:
            if previous:prior_path.unlink(missing_ok=True)
            raise
        return {'port':external_port,'container':name,'previous':previous.get('name') if previous else None}
    except Exception:
        # Snapshot the failed run BEFORE docker rm -f destroys its evidence.
        try:
            capture_customer_diagnostics(STATE, environment, rid, name,
                                         failure='container_start_or_health', reason=failure_reason)
        except Exception:
            logger.warning('AUTOKOM_CUSTOMER_DIAGNOSTIC_CAPTURE_FAILED run=%s', rid)
        if relay is not None:
            try:
                ingress.remove(name, execute=run, available=PROXY, enabled=ENABLED)
            except Exception:
                logger.error('AUTOKOM_INGRESS_CLEANUP_FAILED')
        subprocess.run(['docker','rm','-f',name],capture_output=True,timeout=20)
        raise
def _rollback(params):
    env = valid_id(params.get('environment_id'))
    rid = valid_id(params.get('run_id'))
    state = _load_state(env)
    if not state or state['run_id'] != rid:
        return {'rolled_back': False}
    old_path = STATE / env / 'previous.json'
    previous = json.loads(old_path.read_text()) if old_path.is_file() else None

    # First detach or repoint public routes while the failed container and its
    # ingress are still present.  The earlier ordering stopped Docker first,
    # which briefly exposed an upstream that could only return HTTP 502.
    for owner in STATE.glob('domain-owner-*.txt'):
        if owner.is_symlink() or not owner.is_file() or owner.read_text(encoding='utf-8').strip() != env:
            continue
        host = owner.name[len('domain-owner-'):-len('.txt')]
        if not HOSTNAME.fullmatch(host):
            continue
        conf = PROXY / ('autokom-customer-' + host + '.conf')
        link = ENABLED / conf.name
        if previous:
            # A previously healthy publication keeps its TLS front door.
            if conf.is_symlink() or (link.is_symlink() and link.resolve() != conf):
                raise BrokerError('AUTOKOM_ROLLBACK_VHOST_INVALID: Vhost modifié hors AUTOKOM.')
            with tempfile.NamedTemporaryFile('w', dir=PROXY, delete=False,
                                             prefix='.autokom-rollback-', encoding='utf-8') as fd:
                fd.write(_nginx_config(host, previous['port'], tls=True, gateway_port=previous.get('gateway_port'),gateway_hostname=previous.get('gateway_hostname')))
                tmp = Path(fd.name)
            try:
                os.chmod(tmp, 0o644)
                os.replace(tmp, conf)
            finally:
                tmp.unlink(missing_ok=True)
            if not link.is_symlink():
                link.symlink_to(conf)
        else:
            # Disable the public route first; never leave a dangling symlink.
            if link.is_symlink():
                if link.resolve() != conf:
                    raise BrokerError('AUTOKOM_ROLLBACK_VHOST_INVALID: Lien Nginx modifié.')
                link.unlink()
    try:
        run(['nginx', '-t'])
        run(['systemctl', 'reload', 'nginx'])
    except BrokerError as exc:
        raise BrokerError('AUTOKOM_ROLLBACK_NGINX_FAILED: Retour arrière Nginx incomplet.') from exc

    # The relay must be safely detached before stopping its container.
    if state.get('ingress_mode') == ingress.MODE:
        ingress.remove(state['name'], execute=run, available=PROXY, enabled=ENABLED)
    run(['docker', 'rm', '-f', state['name']], timeout=20)
    if previous:
        _save_state(env, previous)
    else:
        (STATE / env / 'current.json').unlink(missing_ok=True)
    for owner in STATE.glob('domain-owner-*.txt'):
        if owner.is_symlink() or not owner.is_file() or owner.read_text(encoding='utf-8').strip() != env:
            continue
        host = owner.name[len('domain-owner-'):-len('.txt')]
        if previous is None and HOSTNAME.fullmatch(host):
            (PROXY / ('autokom-customer-' + host + '.conf')).unlink(missing_ok=True)
            owner.unlink(missing_ok=True)
    old_path.unlink(missing_ok=True)
    return {'rolled_back': True, 'previous_available': previous is not None}

def _commit(params):
    env=valid_id(params.get('environment_id'))
    rid=valid_id(params.get('run_id'))
    state=_load_state(env)
    if not state or state.get('run_id')!=rid:
        raise BrokerError('Version active différente du déploiement demandé.')
    previous_path=STATE/env/'previous.json'
    if previous_path.is_file():
        previous=json.loads(previous_path.read_text())
        if previous.get('name') and previous['name'] != state['name']:
            old_name=valid_container_name(previous['name'])
            present=subprocess.run(['docker','container','inspect',old_name],capture_output=True,timeout=12)
            if present.returncode==0:
                run(['docker','rm','-f',old_name],timeout=20)
            if previous.get('ingress_mode') == ingress.MODE:
                ingress.remove(old_name, execute=run, available=PROXY, enabled=ENABLED)
        previous_path.unlink(missing_ok=True)
    if PREPROD:
        return {'committed': True, 'image_digest': state.get('image_digest', '')}
    # Publish the already-committed image asynchronously. This is a private
    # artifact mirroring queue, never an HA activation or a client DNS cutover.
    # A registry outage must not roll back a validated local release.
    try:
        queue = Path('/var/lib/autokom/ha/publish-queue')
        if queue.is_symlink():
            raise BrokerError('HA publication queue symlink denied')
        queue.mkdir(mode=0o700, parents=True, exist_ok=True)
        if queue.stat().st_uid != 0 or queue.stat().st_mode & 0o077:
            raise BrokerError('HA publication queue is not private root-owned')
        published = Path('/var/lib/autokom/ha/published') / (rid + '.json')
        if not published.is_file():
            item = queue / (rid + '.json')
            if item.is_symlink():
                raise BrokerError('HA publication item symlink denied')
            if not item.exists():
                with tempfile.NamedTemporaryFile('w', dir=queue, delete=False,
                                                 prefix='.publish-', encoding='utf-8') as stream:
                    os.fchmod(stream.fileno(), 0o600)
                    json.dump({'run_id': rid, 'environment_id': env}, stream)
                    stream.write('\n')
                    tmp = stream.name
                os.replace(tmp, item)
    except Exception as exc:
        logger.warning('AUTOKOM_HA_AUTO_PUBLISH_QUEUE_FAILED reason=%s', type(exc).__name__)
    return {'committed':True}


def _commit_pair(params):
    items = params.get('services')
    if not isinstance(items, list) or len(items) != 2:
        raise BrokerError('AUTOKOM_STACK_COMMIT_INVALID')
    checked = []
    for item in items:
        if not isinstance(item, dict):
            raise BrokerError('AUTOKOM_STACK_COMMIT_INVALID')
        env, rid = valid_id(item.get('environment_id')), valid_id(item.get('run_id'))
        state = _load_state(env)
        if not state or state.get('run_id') != rid:
            raise BrokerError('AUTOKOM_STACK_STATE_MISMATCH')
        checked.append((env, rid))
    if len({env for env, _ in checked}) != 2:
        raise BrokerError('AUTOKOM_STACK_DUPLICATE_ENVIRONMENT')
    # The previously running containers are removed only after BOTH new
    # releases have passed internal health and public TLS checks.
    results = []
    for env, rid in checked:
        try:
            results.append(_commit({'environment_id': env, 'run_id': rid}))
        except Exception as exc:
            # Never perform an automatic rollback after one commit: the old
            # container may have been deleted. Leave an explicit reconciliation.
            raise BrokerError('AUTOKOM_STACK_COMMIT_RECONCILE_REQUIRED') from exc
    return {'committed': True, 'services': len(results),
            'image_digests': {rid: result.get('image_digest', '') for (_,rid),result in zip(checked,results)}}


def _dig(record,hostname):
    """Only publicly observed DNS counts, not a local split-horizon BIND zone."""
    if record not in ('A','TXT'):
        raise BrokerError('Type DNS refusé.')
    answers=[]
    for resolver in ('1.1.1.1','8.8.8.8'):
        output=run(['dig','@'+resolver,'+short','+time=2','+tries=1',record,hostname],
                   timeout=6,max_output=3000)
        answers.append({line.strip().strip('"').rstrip('.') for line in output.splitlines() if line.strip()})
    return sorted(answers[0] & answers[1])


def _ha_ingress(host, origin, environment=None, record_id=None):
    if PREPROD:
        return None
    from autokom_ha_dns import accepted_ip
    return accepted_ip(host, origin, environment, record_id)


def _managed_a_target(host, content, origin, environment=None, record_id=None):
    return isinstance(content, str) and (
        content == origin or content == _ha_ingress(host, origin, environment, record_id)
    )


def _check_dns(host,token,managed):
    valid_hostname(host)
    ingress=_runtime_dns_env().get('AUTOKOM_INGRESS_IPV4','')
    try:ipaddress.IPv4Address(ingress)
    except ValueError:raise BrokerError('AUTOKOM_INGRESS_IPV4_MISSING: Adresse IPv4 publique non configurée.')
    if managed:
        suffix=_runtime_dns_env().get('AUTOKOM_MANAGED_DOMAIN_SUFFIX','').strip('.').lower()
        if not suffix or not host.endswith('.'+suffix) or host==suffix:
            raise BrokerError('AUTOKOM_DOMAIN_SUFFIX_MISMATCH: Sous-domaine hors de la zone gérée.')
    else:
        if not isinstance(token,str) or not re.fullmatch(r'[A-Za-z0-9_-]{32,128}',token):
            raise BrokerError('Preuve de domaine manquante.')
        if 'autokom-verification='+token not in _dig('TXT','_autokom-challenge.'+host):
            raise BrokerError('AUTOKOM_DNS_TXT_PROOF_MISSING: Enregistrement TXT de propriété manquant.')
    answers = _dig('A',host)
    ha_ip = _ha_ingress(host, ingress) if managed and ingress not in answers else None
    if ingress not in answers and (not ha_ip or ha_ip not in answers):
        raise BrokerError('AUTOKOM_DNS_A_MISMATCH: A record DNS ne pointe pas vers l’ingress AUTOKOM.')
    return {'verified':True,'ipv4':ha_ip or ingress}

def _runtime_dns_env():
    """Read authoritative root-owned runtime DNS settings for *every* request.

    A CLI env edit must not leave DNS/HTTPS using the stale systemd process
    environment. Reject unexpected permissions and symlinks; never print secrets.
    The process environment is only a backward-compatible fallback when no
    centralized runtime file exists (including the isolated test environment).
    """
    path = RUNTIME_CONFIG
    if path.is_symlink():
        raise BrokerError('AUTOKOM_RUNTIME_ENV_PERMISSIONS: Lien symbolique interdit.')
    if not path.exists():
        return os.environ
    try:
        details = path.stat()
        if not stat.S_ISREG(details.st_mode) or details.st_uid != 0 or (stat.S_IMODE(details.st_mode) & 0o077):
            raise BrokerError('AUTOKOM_RUNTIME_ENV_PERMISSIONS: Configuration runtime attendue root:0600.')
        from autokom_env_manager import read_env
        return read_env(path)
    except BrokerError:
        raise
    except (OSError, ValueError, ImportError, RuntimeError) as exc:
        raise BrokerError('AUTOKOM_RUNTIME_ENV_INVALID: Configuration runtime illisible.') from exc


def _domain_config_check(params):
    """Compare actual reserved names and Django settings to the broker policy.

    This is strictly read-only and must run BEFORE Jenkins dispatch. Do not
    weaken the allowed suffix or silently authorize a different Cloudflare zone.
    """
    try:
        config = _cloudflare_settings()
    except BrokerError:
        # The UI can still display public DNS parameters when Cloudflare is
        # not provisioned. Build dispatch with managed_hosts stays fail-closed.
        if params.get('managed_hosts') is not None:
            raise
        runtime = _runtime_dns_env()
        suffix = str(runtime.get('AUTOKOM_MANAGED_DOMAIN_SUFFIX', '')).strip('.').lower()
        ingress = str(runtime.get('AUTOKOM_INGRESS_IPV4', '')).strip()
        try:
            if not ipaddress.IPv4Address(ingress).is_global:
                ingress = ''
        except ValueError:
            ingress = ''
        return {'ready': False, 'ingress_ipv4': ingress,
                'managed_suffix': suffix if HOSTNAME.fullmatch('test.' + suffix) else '',
                'dns_zone': ''}
    suffix = config['suffix']
    declared = params.get('managed_suffix')
    if declared is not None:
        if not isinstance(declared, str) or declared != declared.strip('.').lower() or not HOSTNAME.fullmatch('probe.' + declared):
            raise BrokerError('AUTOKOM_DOMAIN_PREFLIGHT_INVALID: Suffixe applicatif invalide.')
        if declared != suffix:
            raise BrokerError('AUTOKOM_DOMAIN_SUFFIX_MISMATCH: Suffixes Django et broker différents.')
    hosts = params.get('managed_hosts')
    if hosts is not None:
        if (not isinstance(hosts, list) or not 1 <= len(hosts) <= 20
                or len(set(map(str, hosts))) != len(hosts)):
            raise BrokerError('AUTOKOM_DOMAIN_PREFLIGHT_INVALID: Liste des domaines gérés invalide.')
        for host in hosts:
            valid_hostname(host)
            if (host != host.strip('.').lower() or not host.endswith('.' + suffix)
                    or (config['zone_name'] and not host.endswith('.' + config['zone_name']))):
                raise BrokerError('AUTOKOM_DOMAIN_SUFFIX_MISMATCH: Domaine réservé hors de la zone autorisée.')
        email = _runtime_dns_env().get('AUTOKOM_ACME_EMAIL', '')
        if not isinstance(email, str) or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
            raise BrokerError('AUTOKOM_ACME_EMAIL_MISSING: Adresse de contact TLS absente.')
    return {'ready': True, 'ingress_ipv4': config['address'],
            'managed_suffix': suffix, 'dns_zone': config['zone_name']}


def _cloudflare_settings():
    """Resolve the root-only DNS configuration for *each* request.

    This also picks up a completed `autokom dns cloudflare env setup` without
    waiting for an unrelated platform rebuild or systemd environment reload.
    Never log, return, or expose the API token through the broker socket.
    """
    conf = {}
    path = CLOUDFLARE_CONFIG
    if path.is_symlink():
        raise BrokerError('AUTOKOM_CF_SECRETS_PERMISSIONS: Lien symbolique interdit.')
    if path.exists():
        info = path.stat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or (stat.S_IMODE(info.st_mode) & 0o077):
            raise BrokerError('AUTOKOM_CF_SECRETS_PERMISSIONS: Configuration DNS attendue root:0600.')
        from autokom_env_manager import read_env
        try:
            conf = read_env(path)
        except Exception as exc:
            raise BrokerError('AUTOKOM_CF_SECRETS_INVALID: Configuration DNS illisible.') from exc
        # A configured file is authoritative: do not silently mix its token
        # with another Cloudflare account left in a process environment.
        zone = conf.get('CLOUDFLARE_ZONE_ID','').strip().lower()
        token = conf.get('CLOUDFLARE_API_TOKEN','').strip()
        zone_name = conf.get('CLOUDFLARE_ZONE_NAME','').strip('.').lower()
    else:
        zone = (os.environ.get('CLOUDFLARE_ZONE_ID') or os.environ.get('AUTOKOM_CLOUDFLARE_ZONE_ID') or '').strip().lower()
        token = (os.environ.get('CLOUDFLARE_API_TOKEN') or os.environ.get('AUTOKOM_CLOUDFLARE_TOKEN') or '').strip()
        zone_name = os.environ.get('CLOUDFLARE_ZONE_NAME','').strip('.').lower()
    runtime = _runtime_dns_env()
    suffix = runtime.get('AUTOKOM_MANAGED_DOMAIN_SUFFIX','').strip('.').lower()
    address = runtime.get('AUTOKOM_INGRESS_IPV4','').strip()
    if not suffix or not HOSTNAME.fullmatch('probe.'+suffix):
        raise BrokerError('AUTOKOM_DOMAIN_SUFFIX_MISSING: Suffixe des sites AUTOKOM absent.')
    if not re.fullmatch(r'[a-f0-9]{32}',zone) or not token:
        raise BrokerError('AUTOKOM_DOMAIN_CLOUDFLARE_CONFIG_MISSING: Configurer sudo autokom dns cloudflare env setup.')
    if zone_name and not (suffix==zone_name or suffix.endswith('.'+zone_name)):
        raise BrokerError('AUTOKOM_CF_ZONE_MISMATCH: Zone Cloudflare incompatible avec le domaine géré.')
    try:
        ip = ipaddress.IPv4Address(address)
        if not ip.is_global:
            raise ValueError('Adresse non publique')
    except ValueError as exc:
        raise BrokerError('AUTOKOM_INGRESS_IPV4_MISSING: IP publique ingress absente ou invalide.') from exc
    return {'zone':zone,'token':token,'zone_name':zone_name,'suffix':suffix,'address':address}


def _managed_client_host(host, suffix):
    if not host.endswith('.' + suffix):
        return False
    labels = host[:-(len(suffix) + 1)].split('.')
    return len(labels) == 1 or (len(labels) == 2 and labels[0] in ('pre', 'backend'))


def _managed_hostname_available(host):
    """Read-only check of the authoritative DNS zone and local vhost ownership.

    A matching record (even pointing at our ingress) is considered occupied;
    domain edits must never take over pre-existing DNS entries.
    """
    host = valid_hostname(host)
    config = _cloudflare_settings()
    suffix = config['suffix']
    if not _managed_client_host(host, suffix):
        raise BrokerError('AUTOKOM_DOMAIN_SUFFIX_MISMATCH')
    if host in ('backend.' + suffix, 'pre.' + suffix):
        return {'available': False, 'reason': 'reserved'}
    owner = STATE / ('domain-owner-' + host + '.txt')
    if owner.exists() or owner.is_symlink():
        return {'available': False, 'reason': 'runtime_reserved'}
    name = 'autokom-customer-' + host + '.conf'
    if (PROXY / name).exists() or (PROXY / name).is_symlink() or (ENABLED / name).exists() or (ENABLED / name).is_symlink():
        return {'available': False, 'reason': 'runtime_reserved'}
    base = 'https://api.cloudflare.com/client/v4/zones/' + config['zone'] + '/dns_records'
    req = Request(base + '?' + urlencode({'name': host, 'per_page': 100}),
                  headers={'Authorization': 'Bearer ' + config['token']})
    try:
        with urllib.request.urlopen(req, timeout=12) as response:
            document = json.load(response)
    except (HTTPError, OSError, ValueError, TimeoutError) as exc:
        raise BrokerError('AUTOKOM_CF_DNS_UNAVAILABLE') from exc
    if not isinstance(document, dict) or document.get('success') is not True:
        raise BrokerError('AUTOKOM_CF_DNS_UNAVAILABLE')
    records = document.get('result')
    if not isinstance(records, list) or len(records) >= 100:
        raise BrokerError('AUTOKOM_CF_DNS_UNAVAILABLE')
    occupied = any(isinstance(record, dict) and
                   str(record.get('name', '')).rstrip('.').lower() == host and
                   record.get('type') in ('A', 'AAAA', 'CNAME')
                   for record in records)
    return {'available': not occupied, 'reason': 'dns_reserved' if occupied else 'available'}



def _managed_hostname_reusable(host, environment_id):
    """Allow reuse ONLY of a domain already reserved in this environment.

    Django authenticates project + domain ownership. This privileged check
    rejects any foreign Nginx owner or DNS record; a matching public IP alone
    is never proof of ownership. A missing DNS A can be recreated safely.
    """
    host = valid_hostname(host)
    env = valid_id(environment_id)
    cfg = _cloudflare_settings()
    suffix = cfg['suffix']
    if not _managed_client_host(host, suffix):
        raise BrokerError('AUTOKOM_DOMAIN_SUFFIX_MISMATCH')
    owner = STATE / ('domain-owner-' + host + '.txt')
    conf = PROXY / ('autokom-customer-' + host + '.conf')
    link = ENABLED / conf.name
    if owner.is_symlink() or conf.is_symlink() or (link.exists() and not link.is_symlink()):
        return {'available': False, 'reason': 'invalid_runtime_owner'}
    if owner.is_file():
        if owner.read_text(encoding='utf-8').strip() != env:
            return {'available': False, 'reason': 'foreign_runtime_owner'}
    elif conf.exists() or link.is_symlink():
        return {'available': False, 'reason': 'unowned_nginx_config'}
    if link.is_symlink() and link.resolve() != conf.resolve():
        return {'available': False, 'reason': 'invalid_nginx_link'}

    base = 'https://api.cloudflare.com/client/v4/zones/' + cfg['zone'] + '/dns_records'
    request = Request(base + '?' + urlencode({'name': host, 'per_page': 100}),
                      headers={'Authorization': 'Bearer ' + cfg['token']})
    try:
        with urllib.request.urlopen(request, timeout=12) as response:
            doc = json.load(response)
    except (HTTPError, OSError, ValueError, TimeoutError) as exc:
        raise BrokerError('AUTOKOM_CF_DNS_UNAVAILABLE') from exc
    if not isinstance(doc, dict) or doc.get('success') is not True:
        raise BrokerError('AUTOKOM_CF_DNS_UNAVAILABLE')
    records = doc.get('result')
    if not isinstance(records, list) or len(records) >= 100:
        raise BrokerError('AUTOKOM_CF_DNS_UNAVAILABLE')
    records = [record for record in records if isinstance(record, dict) and
               str(record.get('name', '')).rstrip('.').lower() == host and
               record.get('type') in ('A', 'AAAA', 'CNAME')]
    if not records:
        return {'available': True, 'reason': 'owned_dns_missing'}
    if len(records) != 1:
        return {'available': False, 'reason': 'dns_conflict'}
    record = records[0]
    if (record.get('type') != 'A' or not _managed_a_target(host, record.get('content'), cfg['address'], env, record.get('id')) or
            record.get('proxied') is not False):
        return {'available': False, 'reason': 'dns_target_mismatch'}
    if record.get('comment') != DNS_COMMENT and not owner.is_file():
        return {'available': False, 'reason': 'dns_unowned'}
    return {'available': True, 'reason': 'owned_by_project'}


def _cloudflare_record(host):
    settings = _cloudflare_settings()
    suffix,zone,token = settings['suffix'],settings['zone'],settings['token']
    if host == 'pre.' + suffix:
        raise BrokerError('AUTOKOM_CONTROL_HOST_RESERVED: Domaine réservé au plan de contrôle.')
    if not host.endswith('.'+suffix) or (PREPROD and not _managed_client_host(host, suffix)):
        raise BrokerError('AUTOKOM_DOMAIN_SUFFIX_MISMATCH: Domaine extérieur à la zone gérée.')
    ingress = settings['address']
    base='https://api.cloudflare.com/client/v4/zones/'+zone+'/dns_records'
    headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'}
    zone_name=settings['zone_name']
    if zone_name and (host==zone_name or not host.endswith('.'+zone_name)):
        raise BrokerError('AUTOKOM_CF_ZONE_MISMATCH: Domaine hors de la zone Cloudflare configurée.')
    def cloudflare(request):
        try:
            with urllib.request.urlopen(request,timeout=12) as response:
                document=json.load(response)
        except HTTPError as exc:
            if exc.code in (401,403):
                raise BrokerError('AUTOKOM_CF_AUTH_DENIED: Vérifier les droits DNS Read et DNS Write du token Cloudflare.') from exc
            if exc.code==429:
                raise BrokerError('AUTOKOM_CF_RATE_LIMITED: Limite Cloudflare atteinte; nouvelle tentative programmée.') from exc
            raise BrokerError('AUTOKOM_CF_DNS_UNAVAILABLE: API Cloudflare indisponible.') from exc
        except (OSError,ValueError,TimeoutError) as exc:
            raise BrokerError('AUTOKOM_CF_DNS_UNAVAILABLE: API Cloudflare indisponible.') from exc
        if not isinstance(document,dict) or document.get('success') is not True:
            raise BrokerError('AUTOKOM_CF_DNS_REJECTED: Cloudflare refuse la configuration DNS.')
        return document
    # Check both A and CNAME. Cloudflare rejects CNAME/A coexistence; do not
    # overwrite records created outside AUTOKOM or hide an existing conflict.
    for record_type in ('CNAME', 'AAAA', 'A') if PREPROD else ('CNAME', 'A'):
        req=Request(base+'?'+urlencode({'type':record_type,'name':host,'per_page':100}),headers=headers)
        data=cloudflare(req)
        results=[item for item in (data.get('result') or []) if isinstance(item,dict) and item.get('name','').rstrip('.').lower()==host]
        if results:
            if (record_type != 'A' or len(results)!=1 or not _managed_a_target(
                    host, results[0].get('content'), ingress, record_id=results[0].get('id'))
                    or results[0].get('proxied') is not False
                    or (PREPROD and results[0].get('comment') != DNS_COMMENT)
                    or (not PREPROD and results[0].get('comment') == 'AUTOKOM preprod managed A record')):
                raise BrokerError('AUTOKOM_DOMAIN_DNS_CONFLICT: Enregistrement DNS existant différent.')
            return {'created':False}
    payload=json.dumps({'type':'A','name':host,'content':ingress,'ttl':120,'proxied':False,
                        'comment':DNS_COMMENT}).encode()
    req=Request(base,data=payload,headers=headers,method='POST')
    cloudflare(req)
    return {'created':True}

def _cloudflare_remove_owned_record(host, *, legacy_owned_vhost=False, dry_run=False):
    """Delete only an AUTOKOM-owned managed A record, never arbitrary DNS.

    Legacy records without the ownership comment are removable only if AUTOKOM
    had an exact matching runtime owner marker for the same environment.
    An untagged, pending legacy record requires administrator reconciliation.
    """
    config = _cloudflare_settings()
    if not host.endswith('.' + config['suffix']) or host == config['suffix']:
        raise BrokerError('AUTOKOM_DOMAIN_SUFFIX_MISMATCH: DNS hors zone gérée.')
    base = 'https://api.cloudflare.com/client/v4/zones/' + config['zone'] + '/dns_records'
    headers = {'Authorization': 'Bearer ' + config['token'], 'Content-Type': 'application/json'}
    query = Request(base + '?' + urlencode({'name': host, 'per_page': 100}), headers=headers)
    try:
        with urllib.request.urlopen(query, timeout=12) as response:
            doc = json.load(response)
    except (HTTPError, OSError, ValueError, TimeoutError) as exc:
        raise BrokerError('AUTOKOM_CF_DNS_UNAVAILABLE: Lecture DNS impossible.') from exc
    if not isinstance(doc, dict) or doc.get('success') is not True:
        raise BrokerError('AUTOKOM_CF_DNS_REJECTED: Lecture DNS refusée.')
    result = doc.get('result')
    if not isinstance(result, list) or len(result) >= 100:
        raise BrokerError('AUTOKOM_CF_DNS_UNAVAILABLE: Réponse DNS incomplète.')
    records = [record for record in result
               if isinstance(record, dict) and record.get('name', '').rstrip('.').lower() == host
               and record.get('type') in ('A', 'AAAA', 'CNAME')]
    if not records:
        return {'deleted': False}
    if len(records) != 1:
        raise BrokerError('AUTOKOM_DOMAIN_DNS_CONFLICT: Plusieurs enregistrements DNS pour ce nom.')
    record = records[0]
    identifier = record.get('id', '')
    if (record.get('type') != 'A' or (record.get('content') != config['address'] and
            not (legacy_owned_vhost and _managed_a_target(host, record.get('content'), config['address'], record_id=identifier)))
            or record.get('proxied') is not False
            or not isinstance(identifier, str) or not re.fullmatch(r'[a-f0-9]{32}', identifier)):
        raise BrokerError('AUTOKOM_DOMAIN_DNS_CONFLICT: Enregistrement DNS non conforme.')
    if record.get('comment') != DNS_COMMENT and not legacy_owned_vhost:
        raise BrokerError('AUTOKOM_DOMAIN_DNS_UNOWNED: Suppression DNS manuelle requise pour cet ancien enregistrement.')
    if dry_run:
        return {'deletable': True}
    try:
        with urllib.request.urlopen(Request(base + '/' + identifier, headers=headers, method='DELETE'), timeout=12) as response:
            result = json.load(response)
    except (HTTPError, OSError, ValueError, TimeoutError) as exc:
        raise BrokerError('AUTOKOM_CF_DNS_UNAVAILABLE: Suppression DNS impossible.') from exc
    if not isinstance(result, dict) or result.get('success') is not True:
        raise BrokerError('AUTOKOM_CF_DNS_REJECTED: Suppression DNS refusée.')
    return {'deleted': True}


def _remove_owned_domain(params):
    """Unpublish and clean up an owned host; client DB deletion happens later.

    This operation is retriable. Never remove an unrelated Nginx vhost,
    Cloudflare record or TLS certificate. External DNS is user-controlled.
    """
    host = valid_hostname(params.get('hostname'))
    env = valid_id(params.get('environment_id'))
    managed = params.get('managed') is True
    runtime = _runtime_dns_env()
    suffix = str(runtime.get('AUTOKOM_MANAGED_DOMAIN_SUFFIX', '')).strip('.').lower()
    if managed != bool(suffix and host.endswith('.' + suffix) and host != suffix):
        raise BrokerError('AUTOKOM_DOMAIN_SUFFIX_MISMATCH')
    owner = STATE / ('domain-owner-' + host + '.txt')
    if owner.is_symlink():
        raise BrokerError('AUTOKOM_DOMAIN_OWNERSHIP_MISMATCH')
    owned = owner.is_file() and owner.read_text(encoding='utf-8').strip() == env
    # Probe the Cloudflare record and ownership first: never take a working
    # Nginx vhost offline just to discover DNS cannot be safely removed.
    if managed:
        _cloudflare_remove_owned_record(host, legacy_owned_vhost=owned, dry_run=True)
        if not PREPROD:
            from autokom_ha_dns import marker, _change
            if marker(host) and _change(host, env, None, False, None, retiring=True) != 'PRIMARY':
                raise BrokerError('AUTOKOM_HA_DNS_RETIRE_FAILED: Domaine HA non retiré.')
    # `_deactivate_owned_vhost` validates the marker and restores on failure.
    _deactivate_owned_vhost(host, env)
    dns_cleanup = {'deleted': False}
    if managed:
        dns_cleanup = _cloudflare_remove_owned_record(host, legacy_owned_vhost=owned)
    return {'removed': True, 'managed_dns_cleaned': managed,
            'dns_record_deleted': dns_cleanup.get('deleted') is True}


def _nginx_config(host,port,tls=False,*,gateway_port=None,gateway_hostname=None):
    if type(port)!=int or not 1024<=port<=65535:raise BrokerError('Port upstream invalide.')
    safe_host=valid_hostname(host)
    extra = ''
    if gateway_port is not None:
        if type(gateway_port) is not int or not 1024 <= gateway_port <= 65535:
            raise BrokerError('AUTOKOM_STACK_GATEWAY_INVALID')
        # Nginx can reach the backend's strictly loopback-only trusted relay;
        # no cross-origin browser request or Docker published port is needed.
        extra = (
            '    location = /__autokom_backend { return 308 /__autokom_backend/; }\n'
            '    location ^~ /__autokom_backend/ {\n'
            f'        proxy_pass http://127.0.0.1:{gateway_port}/;\n'
            f'        proxy_set_header Host {valid_hostname(gateway_hostname or ("backend." + safe_host))};\n'
            '        proxy_set_header X-Real-IP $remote_addr;\n'
            '        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n'
            '        proxy_set_header X-Forwarded-Proto https;\n'
            '        proxy_connect_timeout 5s;\n'
            '        proxy_read_timeout 60s;\n    }\n'
        )
    if tls:
        cert='/etc/letsencrypt/live/'+safe_host
        return (f'server {{\n    listen 80;\n    server_name {safe_host};\n'
            f'    location ^~ /.well-known/acme-challenge/ {{ root {WEBROOT}; default_type text/plain; try_files $uri =404; }}\n'
            '    location / { return 308 https://$host$request_uri; }\n}\n'
            f'server {{\n' + https_listens() + f'    server_name {safe_host};\n'
            f'    ssl_certificate {cert}/fullchain.pem;\n'
            f'    ssl_certificate_key {cert}/privkey.pem;\n'
            '    ssl_protocols TLSv1.2 TLSv1.3;\n'
            '    client_max_body_size 16m;\n' + extra + f'    location / {{\n        proxy_pass http://127.0.0.1:{port};\n'
            '        proxy_set_header Host $host;\n        proxy_set_header X-Real-IP $remote_addr;\n'
            '        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n'
            '        proxy_set_header X-Forwarded-Proto https;\n'
            '        proxy_connect_timeout 5s;\n        proxy_read_timeout 60s;\n    }\n}\n')
    return (f'server {{\n    listen 80;\n    server_name {safe_host};\n'
            f'    location ^~ /.well-known/acme-challenge/ {{ root {WEBROOT}; default_type text/plain; try_files $uri =404; }}\n'
            '    location / { return 503; }\n}\n')

def _prepare_public_acme_webroot():
    """Use the existing public AUTOKOM ACME root, outside private Django state.

    The broker itself has UMask=0077. Explicitly set traversal permissions
    only on these public root-owned ACME directories, NEVER on /var/lib/autokom.
    Fail closed instead of adopting attacker-owned or world-writable directories.
    """
    if not WEBROOT.is_absolute():
        raise BrokerError('AUTOKOM_ACME_WEBROOT_INVALID: Chemin ACME non absolu.')
    for parent in reversed(WEBROOT.parents):
        if parent.is_symlink() or not parent.is_dir():
            raise BrokerError('AUTOKOM_ACME_WEBROOT_INVALID: Parent symbolique ou non valide.')
    for item in (WEBROOT, WEBROOT / '.well-known',
                 WEBROOT / '.well-known' / 'acme-challenge'):
        if item.is_symlink():
            raise BrokerError('AUTOKOM_ACME_WEBROOT_INVALID: Lien symbolique interdit.')
        if not item.exists():
            item.mkdir(mode=0o755)
        st = item.lstat()
        if (not stat.S_ISDIR(st.st_mode) or st.st_uid not in (0, os.geteuid())
                or stat.S_IMODE(st.st_mode) & 0o022):
            raise BrokerError('AUTOKOM_ACME_WEBROOT_INVALID: Répertoire non fiable ou insécurisé.')
        # These directories contain only public, short-lived ACME tokens.
        # Restrict all other AUTOKOM directories as before.
        os.chmod(item, 0o755)
    return WEBROOT


def _acme_ingress_local_ipv4():
    """Find the incoming private interface on NATed GCP/AWS instances."""
    try:
        response = subprocess.run(['ip', '-j', '-4', 'route', 'get', '1.1.1.1'],
                                  capture_output=True, text=True, timeout=3, check=False)
        if response.returncode:
            return None
        route = json.loads(response.stdout)[0]
        if not isinstance(route, dict) or str(route.get('dev', '')).startswith(
                ('docker', 'br-', 'veth', 'wg', 'tun')):
            return None
        addr = ipaddress.IPv4Address(route.get('prefsrc') or route.get('src'))
        if addr.is_loopback or addr.is_link_local or addr.is_unspecified:
            return None
        return str(addr)
    except (ValueError, KeyError, IndexError, TypeError, OSError, subprocess.TimeoutExpired):
        return None


def _preflight_public_acme_challenge(host):
    """Test the actual vhost (not nginx -t) after an asynchronous reload.

    Brief bounded retry tolerates old Nginx workers just after reload.  Every
    attempt uses a fresh connection with the exact Host header.  Never calls
    Let's Encrypt on an unverified route.
    """
    valid_hostname(host)
    root = WEBROOT / '.well-known' / 'acme-challenge'
    name = 'autokom-preflight-' + secrets.token_hex(12)
    marker = 'autokom-http01-' + secrets.token_hex(16)
    file = root / name
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0)
    fd = os.open(file, flags, 0o644)
    try:
        with os.fdopen(fd, 'w', encoding='ascii') as handle:
            os.fchmod(handle.fileno(), 0o644)  # broker has UMask=0077
            handle.write(marker)
        address = _acme_ingress_local_ipv4() or '127.0.0.1'
        last_status = 'unreachable'
        for attempt in range(5):
            connection = http.client.HTTPConnection(address, 80, timeout=4)
            try:
                connection.request('GET', '/.well-known/acme-challenge/' + name,
                                   headers={'Host': host})
                response = connection.getresponse()
                status = response.status
                body = response.read(256).decode('ascii', errors='replace')
                last_status = str(status)
                if status == 200 and body == marker:
                    logger.info('AUTOKOM_ACME_HTTP01_PREFLIGHT_OK host=%s attempt=%d', host, attempt + 1)
                    return
                if status == 200:
                    last_status = '200-content-mismatch'
            except (OSError, http.client.HTTPException):
                last_status = 'unreachable'
            finally:
                connection.close()
            if attempt < 4:
                time.sleep(0.6)
        logger.warning('AUTOKOM_ACME_HTTP01_PREFLIGHT_FAILED host=%s result=%s', host, last_status)
        raise BrokerError('AUTOKOM_ACME_HTTP01_PREFLIGHT_FAILED: '
                          'Réponse HTTP '+last_status+' ; vérifier le vhost actif et le chemin ACME public.')
    finally:
        file.unlink(missing_ok=True)


def _usable_customer_certificate(host, *, live_root=None):
    """Reuse only a matching and sufficiently valid Certbot certificate.

    OpenSSL checks both SAN/CN and minimum remaining validity.  nginx -t will
    additionally verify that the private key matches the certificate.
    """
    valid_hostname(host)
    directory = (Path('/etc/letsencrypt/live') if live_root is None else Path(live_root)) / host
    certificate = directory / 'fullchain.pem'
    private_key = directory / 'privkey.pem'
    if not certificate.is_file() or not private_key.is_file():
        return False
    try:
        # Both OpenSSL tests are mandatory. Combining -checkhost with -checkend
        # in one invocation can report success based on expiry alone.
        for args in (['-checkhost', host], ['-checkend', '1209600']):
            probe = subprocess.run(['openssl', 'x509', '-in', str(certificate),
                                    '-noout', *args], capture_output=True,
                                   text=True, timeout=8, check=False)
            if probe.returncode:
                return False
    except (OSError, subprocess.TimeoutExpired):
        return False
    return True


def _issue_customer_certificate(host, *, managed):
    """Use DNS-01 for Cloudflare-managed domains; HTTP-01 for external ones.

    Managed-domain DNS credentials already exist on this VM and are root-only.
    DNS-01 does not need a temporary Nginx site or open HTTP/80, and Certbot
    handles the temporary TXT record with the restricted Cloudflare token.
    """
    if _usable_customer_certificate(host):
        logger.info('AUTOKOM_ACME_CERT_REUSED host=%s', host)
        return 'reused'
    email = _runtime_dns_env().get('AUTOKOM_ACME_EMAIL', '')
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
        raise BrokerError('AUTOKOM_ACME_EMAIL_MISSING: Adresse TLS absente.')
    if managed:
        from observability_dns01 import (plugin_available, ensure_certbot_credentials,
                                         certbot_dns01_args, DNS01Error)
        try:
            settings = _cloudflare_settings()
            if host == settings['suffix'] or not host.endswith('.' + settings['suffix']):
                raise BrokerError('AUTOKOM_DOMAIN_SUFFIX_MISMATCH: Domaine hors de la zone gérée.')
            if not plugin_available():
                raise BrokerError('AUTOKOM_ACME_DNS01_PLUGIN_MISSING: '
                                  'Exécuter sudo autokom recover --apply pour installer '
                                  'le plugin Certbot officiel avant de publier.')
            credentials = (ensure_certbot_credentials(settings['token'], folder=Path('/etc/autokom-preprod/acme'))
                           if PREPROD else ensure_certbot_credentials(settings['token']))
            challenge = certbot_dns01_args(host, credentials)
        except DNS01Error as exc:
            raise BrokerError('AUTOKOM_ACME_DNS01_SETUP_FAILED: '
                              'Plugin Certbot Cloudflare ou credentials privés indisponibles.') from exc
        method = 'dns01'
    else:
        challenge = ['--webroot', '-w', str(WEBROOT), '-d', host]
        method = 'http01'
    logger.info('AUTOKOM_ACME_CERT_REQUEST host=%s method=%s', host, method)
    try:
        run(['certbot', 'certonly', '--non-interactive', '--agree-tos', '--no-eff-email',
             '--keep-until-expiring', '--cert-name', host, '--email', email, *challenge],
            timeout=420)
    except BrokerError as exc:
        # Never log the Cloudflare token or the raw Certbot command/output.
        logger.warning('AUTOKOM_ACME_CERT_FAILED host=%s method=%s', host, method)
        raise BrokerError('AUTOKOM_ACME_CERT_FAILED: Émission du certificat '+method+
                          ' refusée ; consulter sudo tail -n 100 /var/log/letsencrypt/letsencrypt.log.') from exc
    if not _usable_customer_certificate(host):
        raise BrokerError('AUTOKOM_ACME_CERT_NOT_VALID: '
                          'Certbot terminé sans certificat correspondant et valide.')
    return method


def _customer_https_probe_address():
    """Probe the actual ingress NIC, not an unrelated loopback 443 listener.

    With GCP's address partition, Nginx accepts public HTTPS on the private
    ingress NIC; an independent loopback virtual server can reject SNI.  The
    persisted root-owned bind policy is the authority for the relevant socket.
    When no policy was configured, legacy Nginx listens on wildcard:443 and
    loopback remains appropriate.
    """
    try:
        addresses = https_bind_addresses()
    except (BindPolicyError, OSError, ValueError) as exc:
        raise BrokerError('AUTOKOM_HTTPS_BIND_POLICY_INVALID: Politique d’écoute HTTPS non fiable.') from exc
    return addresses[0] if addresses else '127.0.0.1'


def _customer_https_probe_once(host, healthcheck, address):
    """Return a real HTTPS response with CA and hostname verification enabled."""
    context = ssl.create_default_context()
    with socket.create_connection((address, 443), timeout=6) as raw:
        with context.wrap_socket(raw, server_hostname=host) as connection:
            connection.settimeout(6)
            connection.sendall(('GET ' + healthcheck + ' HTTP/1.1\r\nHost: ' + host +
                                '\r\nConnection: close\r\n\r\n').encode('ascii'))
            response = http.client.HTTPResponse(connection)
            response.begin()
            status = response.status
            response.close()
            return status


def _customer_https_failure_category(exc):
    """Fixed categories only; never print exception strings or certificates."""
    if isinstance(exc, ssl.SSLCertVerificationError):
        return 'certificate-invalid'
    if isinstance(exc, ssl.SSLError):
        reason = str(getattr(exc, 'reason', '') or '').upper()
        if 'UNRECOGNIZED_NAME' in reason:
            return 'sni-unrecognized'
        if 'WRONG_VERSION' in reason or 'UNKNOWN_PROTOCOL' in reason:
            return 'tls-protocol'
        return 'tls-handshake'
    if isinstance(exc, ConnectionRefusedError):
        return 'listener-refused'
    if isinstance(exc, (TimeoutError, socket.timeout)):
        return 'connect-timeout'
    if isinstance(exc, UnicodeEncodeError):
        return 'request-encoding'
    if isinstance(exc, http.client.HTTPException):
        return 'http-protocol'
    return 'connect-failed'


def _verify_customer_https(host, healthcheck):
    """Prove the customer HTTPS vhost works on the REAL ingress listener.

    HTTPS must be validated with the requested hostname in SNI and certificate
    verification enabled. Transient reload/502 errors can retry. No insecure
    SSL context, HTTP-only success, or loopback fallback can mark success on a
    host with a configured production ingress interface.
    """
    valid_hostname(host)
    if (not isinstance(healthcheck, str) or not healthcheck.startswith('/')
            or any(ch in healthcheck for ch in ('\r', '\n', '#', '%', '\\'))
            or len(healthcheck) > 128):
        raise BrokerError('AUTOKOM_HTTPS_HEALTHCHECK_INVALID: Chemin de validation refusé.')
    address = _customer_https_probe_address()
    last_status = 0
    last_problem = None
    for attempt in range(5):
        try:
            last_status = _customer_https_probe_once(host, healthcheck, address)
            last_problem = None
        except (ssl.SSLError, OSError, http.client.HTTPException, UnicodeEncodeError) as exc:
            last_problem = _customer_https_failure_category(exc)
            logger.warning('AUTOKOM_HTTPS_PROBE host=%s interface=%s result=%s attempt=%d',
                           host, 'ingress' if address != '127.0.0.1' else 'loopback',
                           last_problem, attempt + 1)
            # A permanently invalid certificate must not be ignored or retried.
            if last_problem == 'certificate-invalid':
                break
            if attempt < 4:
                time.sleep(1)
            continue
        if 200 <= last_status < 400:
            logger.info('AUTOKOM_HTTPS_PROXY_VERIFIED host=%s interface=%s status=%d',
                        host, 'ingress' if address != '127.0.0.1' else 'loopback', last_status)
            return
        logger.warning('AUTOKOM_HTTPS_PROBE host=%s interface=%s result=http-%d attempt=%d',
                       host, 'ingress' if address != '127.0.0.1' else 'loopback',
                       last_status, attempt + 1)
        if last_status not in (502, 503, 504):
            break
        if attempt < 4:
            time.sleep(1)
    if last_problem is not None:
        # An optional loopback comparison is diagnostic only, NEVER a pass.
        if address != '127.0.0.1':
            try:
                alternate = _customer_https_probe_once(host, healthcheck, '127.0.0.1')
                logger.warning('AUTOKOM_HTTPS_PROBE host=%s interface=loopback '
                               'result=http-%d diagnostic-only=true', host, alternate)
            except (ssl.SSLError, OSError, http.client.HTTPException, UnicodeEncodeError) as exc:
                logger.warning('AUTOKOM_HTTPS_PROBE host=%s interface=loopback '
                               'result=%s diagnostic-only=true', host,
                               _customer_https_failure_category(exc))
        if last_problem == 'certificate-invalid':
            raise BrokerError('AUTOKOM_HTTPS_CERT_INVALID: Chaîne TLS ou nom DNS du certificat invalide.')
        raise BrokerError('AUTOKOM_HTTPS_SNI_FAILED: Liaison TLS/SNI sur interface publique privée non validée '
                          '(' + last_problem + ').')
    raise BrokerError('AUTOKOM_HTTPS_UPSTREAM_FAILED: '
                      'Le reverse proxy HTTPS retourne HTTP ' + str(last_status) + '.')


def _log_customer_upstream_state(state, host):
    """Diagnostic redacted: no container log lines or environment variables."""
    name = state.get('name', '')
    if not isinstance(name, str) or not ingress.NAME_RE.fullmatch(name):
        return
    try:
        probe = subprocess.run(['docker', 'inspect', name,
                                '--format', '{{json .State}}'],
                               capture_output=True, text=True, timeout=8, check=False)
        if probe.returncode:
            logger.warning('AUTOKOM_CUSTOMER_HEALTH_DIAG host=%s container=missing', host)
            return
        payload = json.loads(probe.stdout)
        if not isinstance(payload, dict):
            raise ValueError('invalid state')
        logger.warning('AUTOKOM_CUSTOMER_HEALTH_DIAG host=%s running=%s restarting=%s oom=%s exit=%s relay=%s',
                       host, payload.get('Running') is True, payload.get('Restarting') is True,
                       payload.get('OOMKilled') is True,
                       payload.get('ExitCode') if type(payload.get('ExitCode')) is int else 'unknown',
                       ingress.probe_relay(name, state.get('port')))
    except (ValueError, OSError, subprocess.TimeoutExpired):
        logger.warning('AUTOKOM_CUSTOMER_HEALTH_DIAG host=%s unavailable', host)


def _proxy_apply(host, environment, *, managed=False):
    valid_hostname(host); valid_id(environment)
    state = _load_state(environment)
    if not state: raise BrokerError('Aucune version saine en service pour cet environnement.')
    # Never steal a vhost owned by a different application.
    for directory in (PROXY, ENABLED):
        if directory.is_dir():
            for item in directory.iterdir():
                if item.is_file() and not item.is_symlink() and not item.name.startswith('autokom-customer-'):
                    try: content = item.read_text(encoding='utf-8', errors='replace')
                    except OSError: continue
                    if re.search(r'(?m)^\s*server_name\s+[^;]*\b' + re.escape(host) + r'\b', content):
                        raise BrokerError('Ce domaine est déjà défini dans un vhost Nginx existant.')
    name = 'autokom-customer-' + host + '.conf'
    owner = STATE / ('domain-owner-' + host + '.txt')
    if owner.is_symlink() or (owner.is_file() and owner.read_text(encoding='utf-8').strip() != environment):
        raise BrokerError('Domaine déjà attribué à un autre environnement.')
    path = PROXY / name
    symlink = ENABLED / name
    if (path.exists() and (path.is_symlink() or not owner.is_file())) or (symlink.exists() and not symlink.is_symlink()):
        raise BrokerError('Vhost existant non géré par AUTOKOM : aucune modification.')
    if symlink.is_symlink() and (symlink.resolve() != path.resolve() or not path.is_file()):
        raise BrokerError('AUTOKOM_DOMAIN_VHOST_DANGLING: Lien Nginx absent ou modifié.')
    old = path.read_text(encoding='utf-8') if path.exists() else None
    had_link = symlink.is_symlink()

    def publish(content):
        with tempfile.NamedTemporaryFile('w', dir=PROXY, delete=False,
                                         prefix='.autokom-', encoding='utf-8') as handle:
            handle.write(content)
            temporary = Path(handle.name)
        try:
            os.chmod(temporary, 0o644)
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)
        if not symlink.is_symlink():
            symlink.symlink_to(path)
        run(['nginx', '-t'])
        run(['systemctl', 'reload', 'nginx'])

    phase = 'certificate'
    try:
        if _usable_customer_certificate(host):
            logger.info('AUTOKOM_ACME_CERT_REUSED host=%s', host)
        else:
            if not managed:
                _prepare_public_acme_webroot()
                phase = 'nginx_http'
                logger.info('AUTOKOM_DOMAIN_ACTIVATION phase=%s status=started host=%s', phase, host)
                publish(_nginx_config(host, state['port'], tls=False, gateway_port=state.get('gateway_port'),gateway_hostname=state.get('gateway_hostname')))
                _preflight_public_acme_challenge(host)
            phase = 'certificate'
            logger.info('AUTOKOM_DOMAIN_ACTIVATION phase=%s status=started host=%s', phase, host)
            _issue_customer_certificate(host, managed=managed)
        phase = 'nginx_https'
        logger.info('AUTOKOM_DOMAIN_ACTIVATION phase=%s status=started host=%s', phase, host)
        publish(_nginx_config(host, state['port'], tls=True, gateway_port=state.get('gateway_port'),gateway_hostname=state.get('gateway_hostname')))
        phase = 'https_verify'
        try:
            _verify_customer_https(host, state.get('healthcheck', '/'))
        except BrokerError:
            _log_customer_upstream_state(state, host)
            raise
        phase = 'ownership_commit'
        owner.write_text(environment, encoding='utf-8')
        os.chmod(owner, 0o600)
        logger.info('AUTOKOM_DOMAIN_ACTIVATION phase=%s status=success host=%s', phase, host)
    except Exception as exc:
        # Retain the exact prior healthy vhost; don't expose a half-built
        # HTTPS configuration referencing a missing certificate.
        logger.warning('AUTOKOM_DOMAIN_ACTIVATION phase=%s status=failed category=%s host=%s',
                       phase, type(exc).__name__, host)
        if old is not None:
            with tempfile.NamedTemporaryFile('w', dir=PROXY, delete=False,
                                             prefix='.autokom-restore-', encoding='utf-8') as stream:
                stream.write(old)
                previous = Path(stream.name)
            os.chmod(previous, 0o644)
            os.replace(previous, path)
        else:
            # Remove the enabled symlink before the source file, regardless of
            # whether the source link predated this transaction.
            symlink.unlink(missing_ok=True)
            path.unlink(missing_ok=True)
        try:
            run(['nginx', '-t'])
            run(['systemctl', 'reload', 'nginx'])
        except BrokerError:
            logger.error('AUTOKOM_DOMAIN_ROLLBACK_INCOMPLETE host=%s', host)
        raise
    return {'active': True, 'hostname': host}


def _domain_inspect(params):
    """Read-only, ownership-verified status for a managed public vhost."""
    host=valid_hostname(params.get('hostname'))
    env=valid_id(params.get('environment_id'))
    conf=PROXY/('autokom-customer-'+host+'.conf')
    link=ENABLED/conf.name
    owner=STATE/('domain-owner-'+host+'.txt')
    if owner.is_symlink() or conf.is_symlink() or (link.exists() and not link.is_symlink()):
        raise BrokerError('AUTOKOM_DOMAIN_OWNERSHIP_MISMATCH: Configuration non conforme.')
    if not owner.is_file() or not conf.is_file() or not link.is_symlink():
        return {'active':False}
    if owner.read_text(encoding='utf-8').strip()!=env:
        raise BrokerError('AUTOKOM_DOMAIN_OWNERSHIP_MISMATCH: Vhost géré par un autre environnement.')
    if link.resolve()!=conf.resolve():
        raise BrokerError('AUTOKOM_DOMAIN_OWNERSHIP_MISMATCH: Lien Nginx incohérent.')
    contents=conf.read_text(encoding='utf-8')
    state=_load_state(env)
    if not state or type(state.get('port')) is not int:
        return {'active':False}
    expected_upstream='proxy_pass http://127.0.0.1:'+str(state['port'])+';'
    active=('server_name '+host+';' in contents and
            tls_detected(contents) and expected_upstream in contents and
            '/etc/letsencrypt/live/'+host+'/fullchain.pem' in contents and
            (Path('/etc/letsencrypt/live')/host/'fullchain.pem').is_file())
    if active:
        # A valid local vhost is NOT proof of publicly reachable DNS.
        expected_ip=_runtime_dns_env().get('AUTOKOM_INGRESS_IPV4','')
        try:ipaddress.IPv4Address(expected_ip)
        except ValueError:
            raise BrokerError('AUTOKOM_INGRESS_IPV4_MISSING: IPv4 publique non configurée.')
        answers = _dig('A', host)
        ha_ip = _ha_ingress(host, expected_ip, env) if expected_ip not in answers else None
        active = expected_ip in answers or bool(ha_ip and ha_ip in answers)
    return {'active':bool(active)}


def _deactivate_owned_vhost(host, environment):
    """Remove only a host explicitly assigned to an environment by AUTOKOM.

    Never remove unrelated Nginx files; if Nginx validation/reload fails,
    restore the exact managed configuration before returning a failure.
    """
    valid_hostname(host); valid_id(environment)
    conf=PROXY/('autokom-customer-'+host+'.conf')
    link=ENABLED/conf.name
    owner=STATE/('domain-owner-'+host+'.txt')
    if not owner.is_file():
        if conf.exists() or conf.is_symlink() or link.exists() or link.is_symlink():
            raise BrokerError('AUTOKOM_DOMAIN_OWNERSHIP_MISSING: Vhost présent sans propriété enregistrée.')
        return False
    if owner.is_symlink() or owner.read_text(encoding='utf-8').strip()!=environment:
        raise BrokerError('AUTOKOM_DOMAIN_OWNERSHIP_MISMATCH: Domaine attribué ailleurs.')
    if (conf.is_symlink() or not conf.is_file() or not link.is_symlink()
            or link.resolve()!=conf):
        raise BrokerError('AUTOKOM_DOMAIN_VHOST_TAMPERED: Vhost géré non conforme.')
    original=conf.read_bytes()
    if ('server_name '+host+';').encode() not in original:
        raise BrokerError('AUTOKOM_DOMAIN_VHOST_TAMPERED: Configuration inattendue.')
    link.unlink()
    conf.unlink()
    try:
        run(['nginx','-t'],timeout=12)
        run(['systemctl','reload','nginx'],timeout=15)
    except Exception:
        # Retain the original ownership marker while reverting.
        with tempfile.NamedTemporaryFile('wb',dir=PROXY,delete=False,prefix='.autokom-restore-') as stream:
            stream.write(original)
            temporary=stream.name
        os.chmod(temporary,0o644)
        os.replace(temporary,conf)
        link.symlink_to(conf)
        try:
            run(['nginx','-t'],timeout=12)
            run(['systemctl','reload','nginx'],timeout=15)
        except Exception:
            logger.error('AUTOKOM_DOMAIN_RESTORE_INCOMPLETE')
        raise BrokerError('AUTOKOM_DOMAIN_DEACTIVATION_FAILED: Nginx refusé, configuration restaurée.')
    owner.unlink()
    return True


def _deprovision_environment(params):
    """Explicit, owner-checked and retryable runtime teardown, not filesystem deletion.

    Domain DNS records and domain ownership proofs stay in the database; no
    Cloudflare record or Let's Encrypt certificate is deleted blindly.
    """
    env=valid_id(params.get('environment_id'))
    hosts=params.get('hostnames')
    if not isinstance(hosts,list) or len(hosts)>100 or any(not isinstance(h,str) for h in hosts):
        raise BrokerError('AUTOKOM_DOMAIN_LIST_INVALID: Liste des domaines invalide.')
    if len(set(hosts))!=len(hosts):
        raise BrokerError('AUTOKOM_DOMAIN_LIST_INVALID: Doublons de domaine.')
    for host in hosts:valid_hostname(host)
    directory=STATE/env
    if directory.is_symlink():
        raise BrokerError('AUTOKOM_STATE_TAMPERED: Répertoire runtime non conforme.')
    states=[]
    for basename in ('current.json','previous.json'):
        record=directory/basename
        if record.is_symlink():
            raise BrokerError('AUTOKOM_STATE_TAMPERED: Fichier de runtime non conforme.')
        if record.is_file():
            try: data=json.loads(record.read_text(encoding='utf-8'))
            except (OSError,ValueError,UnicodeError) as exc:
                raise BrokerError('AUTOKOM_STATE_TAMPERED: État illisible.') from exc
            if not isinstance(data,dict) or data.get('environment_id')!=env:
                raise BrokerError('AUTOKOM_STATE_TAMPERED: État incohérent.')
            valid_container_name(data.get('name'))
            states.append((record,data))
    # Refuse unlisted managed domain ownership markers for the same environment.
    # A partial deletion must be retriable, not erase an unknown site.
    owned=[]
    for marker in STATE.glob('domain-owner-*.txt'):
        if marker.is_symlink():
            raise BrokerError('AUTOKOM_DOMAIN_OWNERSHIP_MISMATCH: Marqueur symbolique.')
        if marker.is_file() and marker.read_text(encoding='utf-8').strip()==env:
            hostname=marker.name[len('domain-owner-'):-len('.txt')]
            if hostname not in hosts:
                raise BrokerError('AUTOKOM_DOMAIN_LIST_INCOMPLETE: Domaines gérés manquants.')
            owned.append(hostname)
    # Return a cloud-managed A record to the primary before removing its owner.
    # This path already holds the same runtime lock as the delivery timer.
    for host in owned:
        if not PREPROD:
            from autokom_ha_dns import marker, _change
            if marker(host) and _change(host, env, None, False, None, retiring=True) != 'PRIMARY':
                raise BrokerError('AUTOKOM_HA_DNS_RETIRE_FAILED: Domaine HA non retiré.')
        _deactivate_owned_vhost(host,env)
    for record,data in states:
        name=data['name']
        if data.get('ingress_mode')==ingress.MODE:
            ingress.remove(name,execute=run,available=PROXY,enabled=ENABLED)
        present=subprocess.run(['docker','container','inspect',name],capture_output=True,timeout=12)
        if present.returncode==0:
            run(['docker','rm','-f',name],timeout=25)
        record.unlink(missing_ok=True)
    return {'offline':True,'historical_state_retained':True}


def _activate_owned_domain(params):
    host=valid_hostname(params.get('hostname'))
    env=valid_id(params.get('environment_id'))
    _check_dns(host,params.get('token'),params.get('managed') is True)
    return _proxy_apply(host, env, managed=params.get('managed') is True)


def handle(action,params):
    if PREPROD and action.startswith('domain.'):
        if not isinstance(params, dict):
            raise BrokerError('Paramètres non valides.')
        names = ([params['hostname']] if 'hostname' in params else []) + (params.get('managed_hosts') or [])
        suffix = _runtime_dns_env().get('AUTOKOM_MANAGED_DOMAIN_SUFFIX', '')
        if suffix != 'auto.ikom.mg':
            raise BrokerError('AUTOKOM_PREPROD_CONFIG_INVALID: Suffixe inattendu.')
        if any(not _managed_client_host(valid_hostname(host), suffix)
               or host in {'pre.' + suffix, 'backend.' + suffix} for host in names):
            raise BrokerError('AUTOKOM_PREPROD_DOMAIN_DENIED: Domaine hors périmètre.')
        approved = {name.strip() for name in _runtime_dns_env().get('AUTOKOM_PREPROD_ALLOWED_HOSTS', '').split(',')}
        if any(host not in approved for host in names):
            raise BrokerError('AUTOKOM_PREPROD_HOST_NOT_APPROVED: Domaine non attribué à cette instance.')
        if action in {'domain.verify', 'domain.activate'} and params.get('managed') is not True:
            raise BrokerError('AUTOKOM_PREPROD_DOMAIN_DENIED: Domaine personnalisé désactivé.')
        if action == 'domain.dns.create':
            return _runtime_lock_call(lambda p: _cloudflare_record(p['hostname']), params)

    if not isinstance(params,dict):raise BrokerError('Paramètres invalides.')
    if action=='ping':
        try:jenkins_config();configured=True
        except BrokerError:configured=False
        return {'jenkins_configured':configured,'runtime':'docker-local','registry_required':False,'ha_ready':False}
    if action=='jenkins.identity':
        # Read-only, authenticated probe for host rotation health checks. Never
        # return user details, API tokens or Jenkins response bodies to clients.
        status,_,body=jenkins_http('GET','/whoAmI/api/json')
        if status!=200:raise BrokerError('Identité du compte de service Jenkins refusée.')
        try:
            authenticated=json.loads(body).get('authenticated') is True
        except (ValueError,AttributeError,TypeError):
            authenticated=False
        if not authenticated:raise BrokerError('Compte Jenkins non authentifié.')
        return {'authenticated':True}
    if action.startswith('jenkins.'):
        return jenkins_action(action,params)
    if action=='runtime.deploy':
        if 'restore' in params:
            raise BrokerError('AUTOKOM_RESTORE_SCOPE_INVALID')
        return _docker_deploy(params)
    if action=='runtime.restore':
        if not isinstance(params.get('restore'), dict):
            raise BrokerError('AUTOKOM_RESTORE_SCOPE_INVALID')
        return _docker_deploy(params)
    if action=='runtime.rollback':return _runtime_lock_call(_rollback,params)
    if action=='runtime.commit':return _runtime_lock_call(_commit,params)
    if action=='runtime.commit_pair':return _runtime_lock_call(_commit_pair,params)
    if action=='runtime.deprovision':return _runtime_lock_call(_deprovision_environment,params)
    if action=='ha.application.status':
        if PREPROD:
            return {'application': {'status':'UNAVAILABLE','healthy_replicas':0,
                     'http_lb_ready':False,'public_https_ready':False,'requested_replicas':1}}
        env=valid_id(params.get('environment_id'))
        path=Path('/var/lib/autokom/ha/delivery-status.json')
        default={'status':'NOT_DEPLOYED','healthy_replicas':0,'http_lb_ready':False,
                 'public_https_ready':False,'requested_replicas':1}
        if path.is_symlink() or not path.is_file():
            return {'application':default}
        st=path.stat(follow_symlinks=False)
        if st.st_uid!=0 or st.st_size>262144 or st.st_mode & 0o022:
            return {'application':default}
        try:
            report=json.loads(path.read_text(encoding='utf-8'))
            matches=[row for row in (report.get('applications') or [])
                     if isinstance(row,dict) and row.get('environment')==env]
            if len(matches)!=1:
                return {'application':default}
            row=matches[0]
            health=row.get('healthy_replicas',0)
            health=health if type(health) is int and 0<=health<=20 else 0
            status=str(row.get('status','UNKNOWN'))
            if not re.fullmatch(r'[A-Z0-9_]{3,60}',status):status='UNKNOWN'
            selected=row.get('ha') is True
            observed_at=report.get('updated')
            fresh=(type(observed_at) is int and 0 <= time.time() - observed_at <= 330)
            public_ready=(selected and fresh and status=='PUBLIC_HTTPS_ACTIVE' and health>=2
                          and report.get('public_routing_verified') is True)
            if status=='PUBLIC_HTTPS_ACTIVE' and not public_ready:
                status='UNAVAILABLE'
            return {'application':{'status':status,'healthy_replicas':health,
                    'requested_replicas':2 if selected else 1,
                    'http_lb_ready':status in ('HTTP_LB_READY_NOT_HTTPS','PUBLIC_DNS_PROPAGATING','PUBLIC_HTTPS_ACTIVE'),
                    'public_https_ready':public_ready}}
        except (OSError,ValueError,TypeError,AttributeError):
            return {'application':default}
    if action=='runtime.dynamic.preview':
        return _dynamic_preview(params)
    if action=='runtime.dynamic.check':
        from autokom_dynamic_checks import inspect_candidate
        env, rid = valid_id(params.get('environment_id')), valid_id(params.get('run_id'))
        state = _load_state(env)
        if (not state or state.get('run_id') != rid or state.get('ingress_mode') != ingress.MODE
                or not ingress.probe_relay(valid_container_name(state.get('name')), state.get('port'))):
            raise BrokerError('AUTOKOM_DYNAMIC_CANDIDATE_MISSING: Candidat non vérifié.')
        return inspect_candidate(state['port'], state['healthcheck'])
    if action=='runtime.status':
        env=valid_id(params.get('environment_id'))
        return {'runtime':_load_state(env)}
    if action=='runtime.diagnostics':
        env = valid_id(params.get('environment_id'))
        rid = valid_id(params.get('run_id'))
        return read_customer_diagnostics(STATE, env, rid)
    if action=='runtime.logs':
        env=valid_id(params.get('environment_id'))
        state=_load_state(env)
        if not state:return {'logs':[]}
        n=params.get('lines',80)
        if type(n)!=int or not 1<=n<=100:raise BrokerError('Nombre de lignes invalide.')
        try:
            process=subprocess.run(['docker','logs','--tail',str(n),'--timestamps',state['name']],
                                   timeout=12,capture_output=True,text=True,check=False)
        except (OSError,subprocess.TimeoutExpired):
            raise BrokerError('Logs Docker indisponibles.')
        if process.returncode:raise BrokerError('Lecture des logs refusée.')
        raw=(process.stdout+'\n'+process.stderr)[-24000:]
        lines=[line[:500] for line in raw.splitlines()[-n:]
               if not re.search(r'(?i)password|secret|token|authorization|api[_-]?key|gh[us]_|xsmtpsib-',line)]
        return {'logs':lines}
    if action=='domain.config.check':
        return _domain_config_check(params)  # validates actual reserved names before Jenkins
    if action=='domain.inspect':return _domain_inspect(params)
    if action=='domain.verify':
        return _check_dns(params.get('hostname'),params.get('token'),params.get('managed') is True)
    if action=='domain.available':
        return _managed_hostname_available(params.get('hostname'))
    if action=='domain.reuse.check':
        return _managed_hostname_reusable(params.get('hostname'), params.get('environment_id'))
    if action=='domain.dns.create':
        return _cloudflare_record(valid_hostname(params.get('hostname')))
    if action=='domain.activate':
        # Serialise Nginx / Certbot with runtime deploy, rollback and removal.
        # A domain retry cannot rewrite a vhost while another release changes state.
        return _runtime_lock_call(_activate_owned_domain,params)
    if action=='domain.remove':
        return _runtime_lock_call(_remove_owned_domain, params)
    if action=='domain.deactivate':
        def deactivate(p):
            host, env = valid_hostname(p.get('hostname')), valid_id(p.get('environment_id'))
            if not PREPROD:
                from autokom_ha_dns import marker, _change
                if marker(host) and _change(host, env, None, False, None, retiring=True) != 'PRIMARY':
                    raise BrokerError('AUTOKOM_HA_DNS_RETIRE_FAILED: Domaine HA non retiré.')
            return {'deactivated': _deactivate_owned_vhost(host, env)}
        return _runtime_lock_call(deactivate, params)
    raise BrokerError('Opération non autorisée.')

class Handler(socketserver.StreamRequestHandler):
    def handle(self):
        try:
            creds=self.request.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12)
            _,uid,_=struct.unpack('3i',creds)
            if uid not in (0,pwd.getpwnam(SERVICE_USER).pw_uid):
                raise BrokerError('Identité du client Unix refusée.')
            line=self.rfile.readline(MAX_REQUEST+1)
            if len(line)>MAX_REQUEST or not line.endswith(b'\n'):
                raise BrokerError('Requête trop volumineuse.')
            request=json.loads(line)
            if not isinstance(request,dict):raise BrokerError('Format invalide.')
            result=handle(request.get('action',''),request.get('params',{}))
            response={'ok':True,'result':result}
        except Exception as exc:
            # Only the exception CATEGORY reaches the operator journal. No OAuth, env or args.
            safe = isinstance(exc,(BrokerError,ingress.IngressError))
            match = re.match(r'^(AUTOKOM_[A-Z0-9_]{3,80}):',str(exc)) if safe else None
            code = exc.code if isinstance(exc,ingress.IngressError) else (match.group(1) if match else ('AUTOKOM_BROKER_REFUSED' if safe else 'AUTOKOM_BROKER_INTERNAL_ERROR'))
            # Source function/line from this trusted module, NEVER exception text
            # or a traceback containing customer-controlled values.
            source = 'unknown'
            if not safe:
                tb = exc.__traceback__
                while tb is not None:
                    if tb.tb_frame.f_code.co_filename == __file__:
                        source = '%s:%d' % (tb.tb_frame.f_code.co_name, tb.tb_lineno)
                    tb = tb.tb_next
            logger.warning('Broker request denied: %s code=%s origin=%s',
                           type(exc).__name__,code,source)
            # No exception traceback, request content or secret values in response.
            response={'ok':False,'error':str(exc) if safe else 'Erreur interne du service AUTOKOM.', 'code':code}
        self.wfile.write((json.dumps(response,ensure_ascii=False)+'\n').encode())

class Server(socketserver.ThreadingUnixStreamServer):
    daemon_threads=True
    allow_reuse_address=True

def _prepare_socket_directory():
    """Enforce the same root:autokom 0750 boundary after every restart.

    The systemd RuntimeDirectory= setting should already provide these
    attributes. Revalidating them here catches stale directories and prevents
    a misconfigured unit from silently breaking the Django worker.
    """
    directory = SOCKET.parent
    if directory.is_symlink():
        raise BrokerError('Répertoire de contrôle Unix non conforme.')
    directory.mkdir(parents=True, exist_ok=True, mode=0o750)
    details = directory.lstat()
    if not stat.S_ISDIR(details.st_mode) or details.st_uid != 0:
        raise BrokerError('Propriétaire du répertoire Unix non conforme.')
    gid = pwd.getpwnam(SERVICE_USER).pw_gid
    os.chown(directory, 0, gid)
    os.chmod(directory, 0o750)


def _runtime_lock_call(action, params):
    STATE.mkdir(parents=True, exist_ok=True, mode=0o700)
    fd=os.open(NGINX_LOCK if PREPROD else STATE/'.deploy.lock',
               os.O_WRONLY|os.O_CREAT|getattr(os,'O_NOFOLLOW',0),0o600)
    try:
        fcntl.flock(fd,fcntl.LOCK_EX)
        return action(params)
    finally:
        fcntl.flock(fd,fcntl.LOCK_UN)
        os.close(fd)

def _ingress_scan(_unused):
    # A previously approved relay is updated ONLY when its Docker IP changed.
    # The same lock as deploy/rollback/commit prevents lost state updates.
    for folder in STATE.iterdir():
        if not folder.is_dir() or not UUID.fullmatch(folder.name):
            continue
        for filename in ('current.json','previous.json'):
            record=folder/filename
            if not record.is_file() or record.is_symlink():
                continue
            try:
                doc=json.loads(record.read_text(encoding='utf-8'))
                if not isinstance(doc,dict) or doc.get('environment_id')!=folder.name:
                    continue
                if ingress.reconcile(doc,execute=run,available=PROXY,enabled=ENABLED):
                    with tempfile.NamedTemporaryFile('w',dir=folder,delete=False,prefix='.ingress-state-',encoding='utf-8') as fd:
                        os.chmod(fd.name,0o600)
                        json.dump(doc,fd)
                        fd.write('\n')
                        tmp=fd.name
                    os.replace(tmp,record)
                    logger.info('AUTOKOM_INGRESS_IP_RECONCILED')
            except Exception:
                logger.warning('AUTOKOM_INGRESS_RECONCILE_PENDING')

def _ingress_watchdog():
    while True:
        try:
            _runtime_lock_call(_ingress_scan,None)
        except Exception:
            logger.warning('AUTOKOM_INGRESS_WATCHDOG_UNAVAILABLE')
        time.sleep(90)

def main():
    if os.geteuid()!=0:raise SystemExit('Lancer par systemd, utilisateur root.')
    _prepare_socket_directory()
    SOCKET.unlink(missing_ok=True)
    STATE.mkdir(parents=True,exist_ok=True,mode=0o700)
    IMAGES.mkdir(parents=True,exist_ok=True,mode=0o750)
    threading.Thread(target=_ingress_watchdog,name='autokom-ingress-watchdog',daemon=True).start()
    with Server(str(SOCKET),Handler) as server:
        os.chown(SOCKET,0,pwd.getpwnam(SERVICE_USER).pw_gid)
        os.chmod(SOCKET,0o660)
        server.serve_forever(poll_interval=0.4)

if __name__=='__main__':
    main()
