#!/usr/bin/env python3
"""AUTOKOM Jenkins post-install configurator (existing secured instances).

No change to an existing security realm / authorization strategy. Plugin install
uses authenticated Jenkins CLI; secrets never appear in command-line arguments.
"""
import argparse
import base64
import json
from contextlib import contextmanager, ExitStack
import getpass
import tempfile
from urllib.parse import urlsplit
import os
import secrets
import time
import pwd
import re
import subprocess
import sys
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from menu import pick, ask
from tool_banner import section, Activity
from observability_config import load as load_observability_settings
from autokom_install_permissions import private_install_directory
from jenkins_plugin_recovery import install_missing
from jenkins_firstboot import (bootstrap as bootstrap_first_admin, auth_file_if_available,
                               stage_matrix_restriction, matrix_restriction_pending,
                               selected_admin, save_admin_choice, admin_username, interrupted_managed_bootstrap,
                               validate_admin_identity, validate_admin_password)

ROOT = Path(__file__).resolve().parents[2]
JENKINS_HOME = Path('/var/lib/jenkins')
JENKINS_PORT = load_observability_settings().jenkins_port
JENKINS_URL = f'http://127.0.0.1:{JENKINS_PORT}/'
CLI_JAR = Path('/opt/autokom/tools/jenkins-cli.jar')
SENSITIVE = Path('/etc/autokom/secrets')
PLUGIN_SELECTION = Path('/var/lib/autokom/install/jenkins-plugins-selection.json')
PROFILES = ROOT / 'config/jenkins'
ANSI = (sys.stdout.isatty() and 'NO_COLOR' not in os.environ
        and os.environ.get('TERM', '') not in ('', 'dumb'))


def output(symbol, message):
    color = {'✓': '32', '+': '36', '⚠': '33', '✗': '31', '›': '36'}.get(symbol, '0')
    prefix = f'\033[{color}m{symbol}\033[0m' if ANSI else symbol
    print(f'  {prefix} {message}', flush=True)


def command(argv, *, stdin=None, timeout=180, acceptable=(0,), status=''):
    if not status or not sys.stdout.isatty() or os.environ.get('AUTOKOM_LIVE') == '0':
        result = subprocess.run(argv, input=stdin, capture_output=True, text=True, timeout=timeout, check=False)
    else:
        proc = subprocess.Popen(argv, stdin=subprocess.PIPE if stdin is not None else subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        start = time.monotonic()
        shown = False
        try:
            while True:
                try:
                    out, err = proc.communicate(input=stdin, timeout=0.3)
                    break
                except subprocess.TimeoutExpired:
                    stdin = None  # communicate may resume without re-sending input
                    if time.monotonic() - start < 0.6:
                        continue
                    if not shown:
                        sys.stdout.write('\n\n\n')
                        shown = True
                    elapsed = int(time.monotonic() - start)
                    lines = [f'  \033[32m⠸ {status}\033[0m',
                             '  \033[32m↳ Opération Jenkins en cours (résultat après exécution)\033[0m',
                             f'  \033[32m↳ {elapsed//60:02d}:{elapsed%60:02d} écoulées\033[0m']
                    sys.stdout.write('\033[3A')
                    for line in lines:
                        sys.stdout.write('\r\033[2K' + line + '\n')
                    sys.stdout.flush()
            result = subprocess.CompletedProcess(argv, proc.returncode, out, err)
        except Exception:
            proc.kill()
            proc.communicate()
            raise
        finally:
            if shown:
                sys.stdout.write('\033[3A' + ('\r\033[2K\n' * 3) + '\033[3A')
                sys.stdout.flush()
    if result.returncode not in acceptable:
        # CLI stdout may be useful; do not print command line, which can contain auth paths.
        raise RuntimeError(f'Commande échouée ({argv[0]}), code {result.returncode}: {(result.stderr or result.stdout)[-900:]}')
    return result.stdout


def jenkins_state():
    """secure | wizard | unsafe (read-only; never infer readiness from config.xml).

    Jenkins creates a temporary 'admin' AND a secure config.xml during wizard.
    The official completed-setup marker is the authoritative discriminator.
    """
    marker = JENKINS_HOME / 'jenkins.install.UpgradeWizard.state'
    initial = JENKINS_HOME / 'secrets/initialAdminPassword'
    if marker.is_file():
        return 'secure' if jenkins_xml_secure() else 'unsafe'
    # A verified AUTOKOM first-boot can be ready before the wizard marker is
    # persisted. Never treat an unknown controller as secure on this basis.
    if auth_file_if_available() and jenkins_xml_secure():
        return 'secure'
    # Existing instances using a custom provisioning mechanism may be secure
    # without the standard wizard marker. Do not assume they need a reset.
    if not initial.is_file():
        return 'secure' if jenkins_xml_secure() else 'unsafe'
    # New wizard: the only expected account is temporary 'admin'.
    users = active_users()
    if len(users) <= 1 and all(u.name == 'admin' or u.name.startswith('admin_') for u in users):
        return 'wizard'
    if interrupted_managed_bootstrap():
        # The earlier AUTOKOM first-boot hook may have been interrupted.
        # Groovy must still prove any existing account's *old password* before
        # creating the operator-selected account, and never replaces users.
        return 'wizard'
    return 'unsafe'


def trusted_web_url(override=''):
    """Provide a clickable URL only when explicit HTTPS or trusted Nginx discovery.

    Never synthesize a public URL from a private network interface or accept
    arbitrary Jenkins-configured redirects for credential guidance.
    """
    if override:
        parts = urlsplit(override)
        if (parts.scheme != 'https' or not parts.hostname or parts.username or
                parts.password or parts.port not in (None, 443) or parts.query or
                parts.fragment or parts.path not in ('', '/')):
            raise ValueError('--public-url attend une URL HTTPS du type https://jenkins.exemple.org')
        return 'https://' + parts.hostname.lower() + '/'
    try:
        from nginx_discovery import inventory, jenkins_domains
        domains = jenkins_domains(inventory())
        if domains:
            return 'https://' + domains[0] + '/'
    except (ImportError, OSError, RuntimeError, subprocess.SubprocessError):
        pass
    return ''


def first_run_guidance(web_url, *, apply, timeout=900):
    """Deprecated compatibility check: first boot is automated by AUTOKOM."""
    output('›', 'Premier administrateur Jenkins : AUTOKOM gère automatiquement le démarrage sécurisé.')
    if apply:
        raise RuntimeError('Utiliser la configuration AUTOKOM automatique ; aucun assistant Web manuel requis.')
    return False


def read_masked(label):
    """Get a secret from /dev/tty without echo or exposing it in process args."""
    try:
        fd = os.open('/dev/tty', os.O_RDWR | os.O_NOCTTY)
        os.close(fd)
    except OSError as error:
        raise RuntimeError('Terminal interactif requis pour saisir un token masqué ; utiliser --auth-file en automatisation') from error
    try:
        value = getpass.getpass('  ' + label + ': ').strip()
    except (EOFError, OSError) as error:
        raise RuntimeError('Impossible de saisir un secret depuis le terminal ; utiliser --auth-file') from error
    if not value or '\n' in value or '\r' in value:
        raise ValueError('Secret vide ou invalide')
    return value


@contextmanager
def transient_credentials(username, secret, label='auth'):
    """Create a root-private ephemeral file compatible with Jenkins CLI -auth @file."""
    if not re.fullmatch(r'[A-Za-z0-9_.@-]{1,100}', username):
        raise ValueError('Identifiant Jenkins invalide')
    if not secret or '\n' in secret or '\r' in secret or '\x00' in secret:
        raise ValueError('Token/mot de passe invalide')
    with tempfile.TemporaryDirectory(prefix='autokom-jenkins-', dir='/run') as directory:
        path = Path(directory) / label
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as file:
            file.write(username + ':' + secret + '\n' if label == 'auth' else secret + '\n')
        yield str(path)
    # All ephemeral credentials are removed by TemporaryDirectory, success or failure.


class AuthenticationRejected(ValueError):
    """Bad identity, token or administrator permissions; never includes secrets."""


_ADMIN_CHECK = ('import jenkins.model.Jenkins; '
                'Jenkins.get().checkPermission(Jenkins.ADMINISTER); '
                'println("AUTOKOM_ADMIN_AUTHORIZED")')


def verify_rest_identity(auth_file, expected_username=None):
    """Classify a CLI failure using Jenkins' authenticated REST whoAmI API.

    Only 127.0.0.1 is contacted, never a proxy or a redirect. Credentials are
    kept in memory, not placed in subprocess args, logs or exception text.
    """
    try:
        raw = Path(auth_file).read_text(encoding='utf-8').rstrip('\n')
        username, token = raw.split(':', 1)
    except (OSError, UnicodeError, ValueError):
        raise RuntimeError('Fichier temporaire d’authentification Jenkins illisible.') from None
    if not username or not token:
        raise AuthenticationRejected('Compte ou token Jenkins manquant.')

    authorization = 'Basic ' + base64.b64encode((username + ':' + token).encode('utf-8')).decode('ascii')

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, request, fp, code, msg, headers, url):
            return None

    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect)
    request = urllib.request.Request(
        JENKINS_URL + 'whoAmI/api/json',
        headers={'Authorization': authorization, 'Accept': 'application/json',
                 'User-Agent': 'AUTOKOM-Jenkins/1'},
    )
    try:
        with opener.open(request, timeout=10) as response:
            if response.status != 200:
                raise RuntimeError('API Jenkins locale : réponse HTTP inattendue.')
            payload = json.loads(response.read(32768))
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            raise AuthenticationRejected('Compte ou token refusé par Jenkins (HTTP 401/403).') from None
        if exc.code in (301, 302, 303, 307, 308):
            raise RuntimeError('Jenkins redirige l’API locale : vérifier le contexte HTTP et la configuration de sécurité.') from None
        raise RuntimeError(f'API Jenkins locale indisponible (HTTP {exc.code}).') from None
    except (urllib.error.URLError, TimeoutError, ConnectionError, OSError):
        raise RuntimeError(f'Jenkins inaccessible en local sur 127.0.0.1:{JENKINS_PORT} ; vérifier systemctl et curl.') from None
    except (json.JSONDecodeError, UnicodeError, ValueError, TypeError):
        raise RuntimeError('Réponse Jenkins whoAmI invalide : API locale non vérifiable.') from None

    if not isinstance(payload, dict):
        raise RuntimeError('Réponse Jenkins whoAmI non conforme.')
    name = str(payload.get('name') or '')
    if not payload.get('authenticated') or name.casefold() == 'anonymous' or not name:
        raise AuthenticationRejected('Compte ou token non reconnu par Jenkins.')
    if expected_username and name.casefold() != expected_username.casefold():
        raise AuthenticationRejected('Token associé à un autre compte Jenkins.')
    return name


def verify_admin(auth_file, expected_username=None):
    """Check Jenkins CLI identity and Overall/Administer without false retries.

    If the CLI transport fails, use REST to tell a valid token from bad
    credentials. Never interpret a valid token + broken CLI as a login failure.
    """
    try:
        identity = cli(auth_file, ['who-am-i'], timeout=45)
    except (RuntimeError, subprocess.TimeoutExpired, OSError):
        # This is deliberately a *separate* transport. An authenticated REST
        # response proves that the token was valid even if Jenkins CLI failed.
        verify_rest_identity(auth_file, expected_username)
        raise RuntimeError(
            'Token Jenkins accepté par l’API REST, mais le client CLI local échoue. '
            'Vérifier le transport -http, la version de jenkins-cli.jar et les logs Jenkins.'
        ) from None
    match = re.search(r'^\s*Authenticated as:\s*(.*?)\s*$', identity, flags=re.I | re.M)
    if not match or not match.group(1) or match.group(1).casefold() == 'anonymous':
        # Jenkins CLI can silently authenticate as anonymous; REST distinguishes
        # a rejected token from a transport-specific authentication failure.
        verify_rest_identity(auth_file, expected_username)
        raise RuntimeError('Token valide par REST, mais Jenkins CLI utilise un compte anonyme.')
    if expected_username is not None and match.group(1).casefold() != expected_username.casefold():
        raise AuthenticationRejected('Le token ne correspond pas au compte indiqué.')
    try:
        result = cli(auth_file, ['groovy', '='], stdin=_ADMIN_CHECK, timeout=45)
    except (RuntimeError, subprocess.TimeoutExpired, OSError) as exc:
        detail = str(exc).casefold()
        if any(x in detail for x in ('permission', 'accessdenied', 'forbidden',
                                      'http 401', 'http 403', 'unauthorized',
                                      'authentication', 'anonymous', 'missing the overall')):
            raise AuthenticationRejected('Ce compte ne possède pas les droits Overall/Administer.') from None
        raise RuntimeError('Compte reconnu, mais contrôle des droits via Groovy CLI impossible ; vérifier Jenkins CLI et Overall/Administer.') from None
    if 'AUTOKOM_ADMIN_AUTHORIZED' not in result:
        raise RuntimeError('Compte reconnu, mais réponse du contrôle administrateur Jenkins inattendue.')


def _short_step(title):
    """Single, consistently styled heading; no extra box and no giant banner."""
    color = sys.stdout.isatty() and os.environ.get('NO_COLOR') is None and os.environ.get('TERM') not in ('', 'dumb')
    t = f'  ── {title}'
    print(('\033[38;2;125;211;252m' + t + '\033[0m') if color else t, flush=True)


@contextmanager
def authorization_context(args, web_url, *, apply):
    """Three secure interactive attempts, with verification before any mutation.

    --auth-file is a noninteractive automation path: validate once, no prompting.
    Transient token files are deleted after EACH failed attempt and on success.
    """
    if not apply:
        yield ''
        return
    if not args.auth_file and not args.interactive:
        raise RuntimeError('Mode automatique : fournir --auth-file (root:0600).')
    if not args.auth_file and not web_url:
        raise RuntimeError('Aucun domaine HTTPS détecté : configurer Nginx ou --public-url.')

    # Download the Jenkins CLI before asking for a token, not after.
    with Activity('Préparation de Jenkins CLI'):
        ensure_cli_jar(True)
    if args.auth_file:
        path = str(secure_file(args.auth_file))
        with Activity('Vérification des permissions Jenkins'):
            verify_admin(path)
        output('✓', 'Administrateur Jenkins authentifié')
        yield path
        return

    _short_step('ACCÈS ADMINISTRATEUR')
    output('›', 'Créer le token : ' + web_url + 'me/security/')
    output('›', 'Compte = identifiant de connexion Jenkins, pas le token API.')
    def incorrect(reason, remaining):
        if remaining:
            output('⚠', f'{reason} · {remaining} essai(s) restant(s).')
        else:
            raise RuntimeError('Connexion Jenkins refusée après 3 essais. Aucun plugin ni paramètre de sécurité modifié.') from None

    for number in range(1, 4):
        remaining = 3 - number
        try:
            username = ask(f'Compte Jenkins · essai {number}/3',
                           hint='Exemple : admin ou votre identifiant de connexion (pas le token).').strip()
            if not username or not re.fullmatch(r'[A-Za-z0-9_.@-]{1,100}', username):
                raise AuthenticationRejected('Identifiant Jenkins vide ou incorrect.')
            secret = read_masked('Token API · saisie masquée')
        except (AuthenticationRejected, ValueError) as error:
            incorrect(str(error), remaining)
            continue

        # Important: no catch around yield. Any future plugin/Groovy error
        # propagates immediately; it must NOT be treated as a bad password.
        with transient_credentials(username, secret) as path:
            secret = None
            try:
                with Activity('Authentification auprès de Jenkins'):
                    verify_admin(path, expected_username=username)
            except AuthenticationRejected as error:
                incorrect(str(error), remaining)
                continue
            output('✓', 'Compte administrateur vérifié')
            yield path
            return


def prepare_extra_admin(args, stack):
    """Collect a new administrator password privately only when specifically requested."""
    if not args.admin_user or args.admin_password_file:
        return
    if not args.interactive:
        raise ValueError('--admin-password-file requis pour --admin-user sans terminal interactif')
    for attempt in range(1, 4):
        try:
            password = read_masked('Nouveau mot de passe administrateur (16 caractères min.)')
            again = read_masked('Confirmer le mot de passe')
        except ValueError:
            password = again = ''
        if password == again and len(password) >= 16:
            context = stack.enter_context(transient_credentials('unused', password, 'admin-password'))
            args.admin_password_file = context
            password = again = None
            return
        password = again = None
        remaining = 3 - attempt
        if remaining:
            output('⚠', f'Confirmation du mot de passe invalide · {remaining} essai(s) restant(s).')
    raise RuntimeError('Mot de passe du nouvel administrateur invalide après 3 essais. Aucun compte créé.')


def plugin_ids(profile, include_multibranch_scan=False):
    files = ['plugins-baseline.txt'] if profile != 'minimal' else []
    if profile == 'devsecops':
        files += ['plugins-devsecops.txt']
    plugins = []
    for filename in files:
        for line in (PROFILES / filename).read_text(encoding='utf-8').splitlines():
            plugin = line.split('#', 1)[0].strip()
            if plugin and plugin not in plugins:
                if not re.fullmatch(r'[a-z0-9][a-z0-9-]*(?::[\w.\-]+)?', plugin):
                    raise ValueError(f'Nom de plugin invalide: {plugin}')
                plugins.append(plugin)
    if include_multibranch_scan:
        # Separate opt-in manifest: this plugin currently has an unresolved
        # Jenkins security warning, so do not put it in the default profile.
        for line in (PROFILES / 'plugins-optional-webhooks.txt').read_text(encoding='utf-8').splitlines():
            plugin = line.split('#', 1)[0].strip()
            if plugin:
                if not re.fullmatch(r'[a-z0-9][a-z0-9-]*(?::[\w.\-]+)?', plugin):
                    raise ValueError(f'Nom de plugin invalide: {plugin}')
                if plugin not in plugins:
                    plugins.append(plugin)
    return plugins


def local_plugin_ids(path=JENKINS_HOME / 'plugins'):
    """Inventory archives without trusting incomplete or corrupted .jpi files.

    The previous installer could leave an unusable archive after an aborted
    download. Never treat existence alone as a successful plugin installation,
    and never overwrite an unexpected file automatically.
    """
    if not path.exists():
        return set()
    found = set()
    for p in path.iterdir():
        if p.suffix not in ('.jpi', '.hpi'):
            continue
        if p.is_symlink() or not p.is_file():
            raise RuntimeError(f'Archive Jenkins suspecte : {p.name} ; aucun remplacement automatique')
        try:
            with zipfile.ZipFile(p) as archive:
                manifest = archive.read('META-INF/MANIFEST.MF').decode('utf-8', 'replace')
        except (OSError, zipfile.BadZipFile, KeyError, UnicodeError) as error:
            raise RuntimeError(f'Archive Jenkins invalide : {p.name} ; diagnostic nécessaire avant reprise') from error
        if not re.search(r'(?m)^Plugin-Version:\s*[^\s]+', manifest):
            raise RuntimeError(f'Manifeste Jenkins incomplet : {p.name} ; diagnostic nécessaire')
        if not (p.with_name(p.name + '.disabled')).exists():
            found.add(p.stem)
    return found


def active_users():
    users = JENKINS_HOME / 'users'
    return [p for p in users.iterdir() if p.is_dir()] if users.exists() else []


def jenkins_xml_secure():
    cfg = JENKINS_HOME / 'config.xml'
    if not cfg.exists():
        return False
    try:
        root = ET.parse(cfg).getroot()
    except ET.ParseError:
        return False
    realm = root.find('securityRealm')
    auth = root.find('authorizationStrategy')
    if root.findtext('useSecurity') == 'false':
        return False
    return bool(realm is not None and auth is not None and
                'None' not in realm.attrib.get('class', '') and
                'Unsecured' not in auth.attrib.get('class', ''))


def secure_file(path):
    p = Path(path)
    if not p.is_file() or p.is_symlink():
        raise ValueError(f'Fichier absent ou lien symbolique interdit : {p}')
    st = p.stat()
    if st.st_mode & 0o077:
        raise ValueError(f'Permissions trop ouvertes sur {p} : exiger chmod 600')
    if st.st_uid != 0:
        raise ValueError(f'Fichier sensible non propriétaire root : {p}')
    return p


def cli(auth_file, subcommand, *, stdin=None, timeout=300, status=""):
    return command(['java','-jar', str(CLI_JAR),'-s', JENKINS_URL, '-http',
                    '-auth', f'@{auth_file}', *subcommand], stdin=stdin, timeout=timeout, status=status)


def ensure_cli_jar(apply):
    if CLI_JAR.exists():
        return
    if not apply:
        output('+', f'Jenkins CLI à récupérer : {CLI_JAR}')
        return
    CLI_JAR.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
    req = urllib.request.Request(JENKINS_URL + 'jnlpJars/jenkins-cli.jar', headers={'User-Agent': 'Autokom/jenkins-bootstrap'})
    with urllib.request.urlopen(req, timeout=20) as response:
        data = response.read(12 * 1024 * 1024 + 1)
    if len(data) > 12 * 1024 * 1024 or not data.startswith(b'PK'):
        raise RuntimeError('Jenkins CLI jar invalide ou trop grand')
    temp = CLI_JAR.with_suffix('.tmp')
    temp.write_bytes(data)
    temp.chmod(0o644)
    temp.replace(CLI_JAR)


def write_admin_script():
    return (ROOT / 'config/jenkins/provision-admin.groovy').read_text(encoding='utf-8')


def handle_admin(auth_file, username, password_file, apply):
    if not username:
        return
    if not re.fullmatch('[a-zA-Z][a-zA-Z0-9_.-]{2,39}', username):
        raise ValueError('Identifiant admin invalide (3 à 40 caractères)')
    secure_file(password_file)
    output('›', f'Nouvel administrateur demandé : {username} (compte existant jamais remplacé)')
    if not apply:
        return
    secret_location = JENKINS_HOME / ('.autokom-admin-' + secrets.token_hex(12))
    # Secret is read by the Jenkins process via the local Groovy script.
    # Existing admin credentials authorize the action over Jenkins CLI.
    # Atomic creation, exclusive; prevents overwriting a concurrent operation.
    password = Path(password_file).read_text(encoding='utf-8').strip()
    if len(password) < 16 or '\n' in password or '\r' in password:
        raise ValueError('Mot de passe administrateur requis : 16 caractères minimum, une seule ligne')
    try:
        fd = os.open(secret_location, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        jenkins_user = pwd.getpwnam('jenkins')
        os.fchown(fd, jenkins_user.pw_uid, jenkins_user.pw_gid)
        with os.fdopen(fd, 'w', encoding='utf-8') as fp:
            fp.write(username + '\n' + password + '\n')
        script = write_admin_script().replace('__AUTOKOM_ADMIN_FILE__', str(secret_location))
        response = cli(auth_file, ['groovy', '='], stdin=script, timeout=120)
        if 'AUTOKOM_ADMIN_CREATED' in response:
            output('✓', f'Administrateur {username} créé et autorisé')
        elif 'AUTOKOM_ADMIN_ALREADY_EXISTS' in response:
            output('✓', f'Compte {username} déjà présent, préservé')
        else:
            raise RuntimeError('Jenkins n’a pas confirmé la création du compte : vérifier son journal')
    finally:
        secret_location.unlink(missing_ok=True)


def harden(auth_file, apply, controller_zero=False, disable_agents=False):
    text = (ROOT/'config/jenkins/harden-existing.groovy').read_text(encoding='utf-8')
    text = text.replace('__AUTOKOM_CONTROLLER_ZERO__', 'true' if controller_zero else 'false')
    text = text.replace('__AUTOKOM_DISABLE_AGENTS__', 'true' if disable_agents else 'false')
    if not apply:
        return
    result = cli(auth_file, ['groovy', '='], stdin=text, timeout=120)
    if 'AUTOKOM_HARDENED' not in result:
        raise RuntimeError('Durcissement Jenkins non confirmé; voir journaux du service')
    output('✓', 'Contrôles Jenkins appliqués (compte et autorisations existants inchangés)')


def read_initial_admin_password(label):
    """Read the literal password from the terminal; Enter terminates input.

    Unlike a generic token prompt, no .strip() is performed: it must never
    silently alter the operator's selected Jenkins password.
    """
    try:
        fd = os.open('/dev/tty', os.O_RDWR | os.O_NOCTTY)
        os.close(fd)
    except OSError as exc:
        raise RuntimeError('Terminal interactif requis pour le mot de passe Jenkins') from exc
    try:
        return getpass.getpass('  ' + label + ': ')
    except (EOFError, OSError) as exc:
        raise RuntimeError('Saisie du mot de passe Jenkins interrompue ou terminal indisponible') from exc


def choose_initial_administrator():
    """Ask identity once, then retry only the masked password if needed.

    Pressing Enter after the password does not insert CR/LF into the secret.
    Existing Jenkins identities are never reset or overwritten.
    """
    recorded = selected_admin()
    if recorded is not None:
        output('✓', 'Premier administrateur Jenkins : ' + recorded['username'] + ' (choix enregistré, conservé)')
        return recorded
    _short_step('PREMIER ADMINISTRATEUR JENKINS')
    output('›', 'Renseigner le compte dans le terminal ; AUTOKOM réalisera toute la configuration.')
    output('›', 'Mot de passe invisible pendant la saisie ; Entrée valide, sans faire partie du mot de passe.')
    output('›', 'Minimum 16 caractères ; aucun secret ni mot de passe partiel ne sera affiché.')
    for attempt in range(3):
        username = ask('Identifiant Jenkins', hint='3 à 40 caractères ; ne pas utiliser le compte temporaire admin').strip()
        full_name = ask('Nom complet du responsable Jenkins').strip()
        email = ask('E-mail de l’administrateur Jenkins').strip()
        try:
            validate_admin_identity(username, full_name, email)
            break
        except ValueError as error:
            output('⚠', str(error))
    else:
        raise RuntimeError('Identité administrateur Jenkins non valide après trois tentatives')

    for attempt in range(5):
        password = confirmation = None
        try:
            password = read_initial_admin_password('Mot de passe Jenkins (16 caractères min.)')
            validate_admin_password(password)
            confirmation = read_initial_admin_password('Confirmer le mot de passe Jenkins')
            if password != confirmation:
                raise ValueError('Les deux mots de passe ne correspondent pas ; saisir de nouveau le mot de passe')
            result = save_admin_choice(username, full_name, email, password)
            output('✓', 'Administrateur initial ' + result['username'] + ' enregistré ; aucune saisie Web nécessaire')
            return result
        except ValueError as error:
            output('⚠', str(error))
            output('›', 'Identifiant, nom complet et e-mail conservés ; seule la saisie du mot de passe est à reprendre.')
        finally:
            password = confirmation = None
    raise RuntimeError('Mot de passe Jenkins non validé après cinq tentatives ; aucun compte modifié')


def configure(args):
    if os.geteuid() != 0:
        raise RuntimeError('Exécuter en root/sudo')
    if subprocess.run(['systemctl','is-active','--quiet','jenkins']).returncode != 0:
        raise RuntimeError('Jenkins doit être démarré pour l’étape post-installation')
    apply = args.mode == 'apply'
    state = jenkins_state()
    web_url = trusted_web_url(args.public_url)
    if state != 'secure':
        output('›', 'État Jenkins : ' + {'wizard': 'premier démarrage', 'unsafe': 'sécurité incertaine'}[state])
    if state == 'unsafe':
        raise RuntimeError('Sécurité Jenkins absente ou incohérente : aucune modification automatique autorisée')
    first_admin_created = (state == 'wizard' and apply)
    if state == 'wizard':
        if apply and args.interactive:
            choose_initial_administrator()
        elif apply and selected_admin() is None:
            raise RuntimeError('Premier administrateur Jenkins non défini : utiliser le terminal AUTOKOM interactif')
        if not apply:
            output('+', 'Premier administrateur : nom, identifiant, e-mail et mot de passe à saisir dans AUTOKOM')
            output('›', 'Le compte et le token API seront ensuite configurés automatiquement, sans assistant Web.')
            return
        if not args.confirm_restart:
            raise RuntimeError('Autorisation de redémarrage Jenkins requise pour le premier administrateur')
        # The official wizard is replaced only on a fresh, recognizable Jenkins
        # controller. Unknown users or security models are never overwritten.
        with Activity('Initialisation automatique du premier administrateur Jenkins'):
            args.auth_file = bootstrap_first_admin(approved=True, timeout=args.wizard_timeout)
        state = jenkins_state()
        if state != 'secure':
            raise RuntimeError('Jenkins ne confirme pas la sécurité après création du premier administrateur')
        output('✓', 'Compte initial : ' + admin_username() + ' · mot de passe privé : /etc/autokom/secrets/jenkins-first-admin.password')
        output('✓', 'Jeton de configuration AUTOKOM généré et protégé ; aucun assistant Web nécessaire')
    if not args.auth_file and state == 'secure':
        args.auth_file = auth_file_if_available()
    plugins = plugin_ids(args.profile, args.multibranch_scan)
    # Existing installations are never reconfigured automatically. Only the
    # pristine AUTOKOM first admin is promoted to explicit Matrix Administer.
    if apply and first_admin_created and 'matrix-auth' in plugins:
        stage_matrix_restriction(include_metrics=('prometheus' in plugins))
        output('›', 'Après installation : accès administrateur limité par Matrix Authorization')
    present = local_plugin_ids()
    missing = [p for p in plugins if p.split(':',1)[0] not in present]
    # On a new controller the operator-approved Matrix authorization must be
    # provisioned before optional UI plugins; avoid leaving it behind Stage View.
    if matrix_restriction_pending() and 'matrix-auth' in missing:
        missing = ['matrix-auth'] + [p for p in missing if p != 'matrix-auth']
    _short_step('PLUGINS ET SÉCURITÉ')
    output('+' if missing else '✓', f'Profil {args.profile} · {len(plugins) - len(missing)} présents · {len(missing)} à installer')
    if args.multibranch_scan:
        output('⚠', 'Webhook Multibranch optionnel : SECURITY-2875 ; filtrer son endpoint.')
    changes = bool(missing or args.admin_user or args.harden or matrix_restriction_pending())
    if apply and not args.confirm_restart and changes:
        raise RuntimeError('Option --confirm-restart requise AVANT toute modification')
    if args.controller_zero and not args.harden:
        raise ValueError('--controller-zero exige --harden')
    if args.disable_inbound_agents and not args.harden:
        raise ValueError('--disable-inbound-agents exige --harden')
    if args.admin_user and not (args.admin_password_file or args.interactive):
        raise ValueError('--admin-password-file requis avec --admin-user en mode non interactif')
    if not changes:
        output('✓', 'Aucune modification nécessaire : profils déjà présents et sécurité inchangée.')
        return
    if not apply:
        ensure_cli_jar(False)
        if missing:
            output('+', 'Plugins à installer : ' + ', '.join(missing))
        if args.admin_user:
            output('+', 'Nouvel administrateur demandé : ' + args.admin_user)
        if args.harden:
            output('+', 'Contrôles de sécurité Jenkins prévus')
        output('✓', 'Simulation : aucun plugin, compte ou service modifié')
        return
    with ExitStack() as stack:
        auth_file = stack.enter_context(authorization_context(args, web_url, apply=True))
        prepare_extra_admin(args, stack)
        if args.admin_user:
            secure_file(args.admin_password_file)
            password = Path(args.admin_password_file).read_text(encoding='utf-8').strip()
            if len(password) < 16 or '\n' in password or '\r' in password:
                raise ValueError('Mot de passe nouvel administrateur : 16 caractères minimum')
            password = None
        # Le jeton a déjà été vérifié avant toute modification.
        if args.admin_user or args.harden:
            precheck = '''import jenkins.model.Jenkins
import hudson.security.HudsonPrivateSecurityRealm
def j = Jenkins.get()
'''
            if args.admin_user:
                precheck += '''if (!(j.securityRealm instanceof HudsonPrivateSecurityRealm) || j.authorizationStrategy.class.name != 'hudson.security.GlobalMatrixAuthorizationStrategy') throw new IllegalStateException('AUTOKOM: creation admin requiert realm local et stratégie Matrix globale')
'''
            if args.harden:
                precheck += '''if (j.securityRealm instanceof HudsonPrivateSecurityRealm && j.securityRealm.allowsSignup()) throw new IllegalStateException('AUTOKOM: inscription publique active. Désactiver manuellement avant modification')
'''
            precheck += 'println("AUTOKOM_PRECHECK_OK")\n'
            if 'AUTOKOM_PRECHECK_OK' not in cli(auth_file, ['groovy', '='], stdin=precheck, timeout=60):
                raise RuntimeError('Pré-contrôles Jenkins non confirmés')
        _short_step('APPLICATION')
        if missing:
            output('+', f'Installation de {len(missing)} plugins manquants')
            install_missing([p.split(':', 1)[0] for p in missing], cli, auth_file, output=output)
            output('✓', f'Installation des {len(missing)} plugins demandée et confirmée individuellement')
        if args.admin_user:
            handle_admin(auth_file, args.admin_user, args.admin_password_file, True)
        if args.harden:
            harden(auth_file, True, controller_zero=args.controller_zero, disable_agents=args.disable_inbound_agents)
        output('›', 'Redémarrage sécurisé après les builds en cours')
        cli(auth_file, ['safe-restart'], timeout=60, status='Redémarrage sécurisé Jenkins')
        output('✓', 'safe-restart accepté ; vérifier la reprise et les plugins après les builds')

def parse(argv=None):
    p = argparse.ArgumentParser(description='AUTOKOM : configuration initiale de Jenkins existant')
    modes = p.add_mutually_exclusive_group(required=True)
    modes.add_argument('--check', dest='mode', action='store_const', const='check')
    modes.add_argument('--apply', dest='mode', action='store_const', const='apply')
    p.add_argument('--profile', choices=['minimal', 'baseline', 'devsecops'], default='devsecops')
    p.add_argument('--interactive', action='store_true', help='Menus avec flèches et chiffres 1–9')
    p.add_argument('--reconfigure', action='store_true', help='Redemander explicitement les choix de plugins Jenkins')
    p.add_argument('--auth-file', default='', help='Option automatisation : fichier root 0600 avec username:API_TOKEN')
    p.add_argument('--public-url', default='', help='URL HTTPS Jenkins pour la création du token, si Nginx non détectable')
    p.add_argument('--wizard-timeout', type=int, default=900, help='Délai maximal de l’initialisation automatique Jenkins (défaut 900 s)')
    p.add_argument('--admin-user', default='', help='Nouvel admin à créer si absent (pas de reset)')
    p.add_argument('--admin-password-file', default='', help='Mot de passe du nouvel admin en mode 0600')
    p.add_argument('--harden', action='store_true', help='Durcir la sécurité sans changer les droits existants')
    p.add_argument('--disable-inbound-agents', action='store_true', help='Désactiver le port TCP des agents explicitement')
    p.add_argument('--controller-zero', action='store_true', help='Désactiver explicitement les builds sur le contrôleur')
    p.add_argument('--confirm-restart', action='store_true', help='Autoriser le safe-restart après les changements')
    p.add_argument('--multibranch-scan', action='store_true', help='Ajouter multibranch-scan-webhook-trigger (SECURITY-2875, choix explicite)')
    return p.parse_args(argv)


def choose_optional_multibranch(args):
    """Offer insecure optional webhook plugin only with explicit consent.

    A caller specifying --multibranch-scan has already opted in.
    """
    if args.multibranch_scan:
        return args
    if args.profile == 'minimal':
        return args
    option = pick('Webhook Multibranch (optionnel)',
                  ['Non : utiliser GitHub Branch Source (recommandé)',
                   'Oui : installer Multibranch Scan Webhook Trigger'],
                  hint='SECURITY-2875 : avertissement non résolu sur les tokens. Activer seulement si nécessaire.')
    args.multibranch_scan = (option == 2)
    return args


def _load_plugin_selection():
    if not PLUGIN_SELECTION.exists() and not PLUGIN_SELECTION.is_symlink():
        return None
    secure_file(PLUGIN_SELECTION)
    try:
        selection = json.loads(PLUGIN_SELECTION.read_text(encoding='utf-8'))
    except (OSError, ValueError) as exc:
        raise RuntimeError('Choix Jenkins sauvegardés illisibles, ne pas les écraser') from exc
    if not isinstance(selection, dict) or selection.get('schema') != 1:
        raise RuntimeError('Choix Jenkins sauvegardés de version inconnue')
    if selection.get('profile') not in ('minimal','baseline','devsecops'):
        raise RuntimeError('Profil Jenkins sauvegardé non reconnu')
    for field in ('multibranch_scan','harden','controller_zero','disable_inbound_agents'):
        if not isinstance(selection.get(field), bool):
            raise RuntimeError('Choix Jenkins sauvegardés invalides : ' + field)
    return selection


def _save_plugin_selection(args):
    """Root-only, no token/password, restart consent is always per invocation."""
    record={'schema':1, 'profile':args.profile, 'multibranch_scan':bool(args.multibranch_scan),
            'harden':bool(args.harden), 'controller_zero':bool(args.controller_zero),
            'disable_inbound_agents':bool(args.disable_inbound_agents)}
    directory=private_install_directory(PLUGIN_SELECTION.parent)
    if PLUGIN_SELECTION.exists() or PLUGIN_SELECTION.is_symlink():
        secure_file(PLUGIN_SELECTION)
    temp=directory/('.jenkins-selection-' + secrets.token_hex(10))
    fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as writer:
            json.dump(record,writer,sort_keys=True)
            writer.write('\n')
            writer.flush(); os.fsync(writer.fileno())
        os.replace(temp,PLUGIN_SELECTION)
    finally:
        temp.unlink(missing_ok=True)


def _restore_plugin_selection(args):
    saved = _load_plugin_selection()
    if not saved:
        return False
    explicit_webhook = bool(args.multibranch_scan)
    for key in ('profile','multibranch_scan','harden','controller_zero','disable_inbound_agents'):
        setattr(args,key,saved[key])
    if explicit_webhook:
        args.multibranch_scan = True
    args.confirm_restart = args.mode == 'apply'  # only for this explicit CLI run
    output('✓','Profil Jenkins sauvegardé : ' + args.profile + ' (choix réutilisés)')
    output('›','Pour les modifier : sudo autokom configure plugins')
    return True


def interactive_configure(args):
    if not args.reconfigure and _restore_plugin_selection(args):
        return args
    choice = pick('Configuration Jenkins',
                  ['Recommandée : plugins DevSecOps + sécurité, préserver comptes et agents',
                   'Personnaliser les composants'],
                  hint='Option 1 : configuration sécurisée en limitant les interactions et sans remplacer les administrateurs.')
    if choice == 1:
        args.profile = 'devsecops'
        args.harden = True
        args.admin_user = ''
        args.controller_zero = False
        args.disable_inbound_agents = False
        args.confirm_restart = args.mode == 'apply'  # Consentement donné par la sélection de ce profil.
        choose_optional_multibranch(args)
        if args.mode == 'apply':
            _save_plugin_selection(args)
        return args
    i = pick('Jenkins — profil de plugins',
             ['DevSecOps complet', 'Base suggérée AUTOKOM', 'Aucun nouveau plugin'],
             hint='Les plugins déjà installés ne sont ni effacés ni rétrogradés.')
    args.profile = ('devsecops','baseline','minimal')[i-1]
    choose_optional_multibranch(args)
    # AUTOKOM creates the first administrator on a pristine controller.
    # Existing secure controllers keep their administrators unchanged.
    if jenkins_state() != 'wizard':
        i = pick('Jenkins — administrateurs',
                 ['Conserver les administrateurs existants', 'Créer un administrateur supplémentaire'],
                 hint='La création additionnelle nécessite le realm local et la stratégie Matrix globale.')
        if i == 2:
            args.admin_user = ask('Identifiant du nouvel administrateur',
                                  hint='Le compte existant ne sera pas réinitialisé.')
    i = pick('Jenkins — contrôles de sécurité',
             ['Vérifier et renforcer la sécurité', 'Ne rien modifier aux contrôles'],
             hint='Aucun changement du realm ni des permissions des utilisateurs.')
    args.harden = i == 1
    if args.harden:
        i = pick('Agents Jenkins : port TCP',
                 ['Conserver la configuration existante', 'Désactiver les agents TCP entrants'],
                 hint='Choix 2 uniquement si aucun agent entrant ne dépend de ce port.')
        args.disable_inbound_agents = i == 2
        i = pick('Exécution sur le contrôleur Jenkins',
                 ['Conserver les exécuteurs actuels', 'Désactiver les builds sur le contrôleur'],
                 hint='Choix 2 nécessite des agents de build disponibles.')
        args.controller_zero = i == 2
    if args.mode == 'apply':
        i = pick('Redémarrage sécurisé Jenkins',
                 ['Autoriser safe-restart après application', 'Annuler avant toute modification'],
                 hint='safe-restart attend la fin des builds en cours.')
        if i == 2:
            raise RuntimeError('Opération annulée avant modification')
        args.confirm_restart = True
    if args.mode == 'apply':
        _save_plugin_selection(args)
    return args


def main():
    args = parse()
    if args.wizard_timeout < 1:
        raise ValueError('--wizard-timeout doit être positif')
    section('Jenkins · Configuration', 'Plugins · Identifiants · Sécurité', tone='jenkins')
    if args.interactive:
        args = interactive_configure(args)
    configure(args)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, RuntimeError, subprocess.TimeoutExpired, urllib.error.URLError, KeyboardInterrupt) as error:
        output('✗', str(error))
        sys.exit(1)
