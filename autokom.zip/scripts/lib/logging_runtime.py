#!/usr/bin/env python3
"""AUTOKOM logging runtime: one active owner for Loki+Alloy (Docker or systemd).

Native mode is intentionally Loki-only. OpenSearch/Data Prepper remain a distinct
backend and cannot be silently destroyed or severed during a runtime switch.
A mode change is transactional for running services and preserves a durable
backup before removing the former installation. The previous mode is restored
when a pre-cleanup health or canary check fails.
"""
from __future__ import annotations
from cli_colors import pretty_print as print
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import datetime
import urllib.request

NATIVE = Path('/etc/autokom/logs-native')  # root-only state/marker
CONFIG_DIR = Path('/etc/autokom-logging')  # public, non-secret runtime configs
STATE = Path('/etc/autokom/state/logs-runtime.json')
# Never place Loki under Django's private /var/lib/autokom (0750).
# autokom-loki cannot traverse that parent; this is one cause of exit=1.
LEGACY_DATA = Path('/var/lib/autokom/loki')
DATA = Path('/var/lib/autokom-loki')
BACKUP_ROOT = Path('/var/backups/autokom/logs')
UNITS = ('loki','alloy')

class RuntimeErrorSafe(RuntimeError): pass


def cmd(*args, timeout=180, check=True):
    try:
        from tool_banner import Activity
        label=' '.join(str(x) for x in args[:2])
        with Activity('Exécution : '+label):
            p=subprocess.run(list(args),capture_output=True,text=True,timeout=timeout,check=False)
    except (OSError,subprocess.TimeoutExpired) as exc:
        raise RuntimeErrorSafe('Commande indisponible ou expirée: '+str(args[0])) from exc
    if check and p.returncode:
        raise RuntimeErrorSafe('Échec '+ ' '.join(args[:3]) +f' (code {p.returncode}); examiner les journaux locaux')
    return p


def active_native():
    return any(cmd('systemctl','is-active','--quiet',name,check=False).returncode == 0 for name in UNITS)


def active_docker():
    if not shutil.which('docker'):return False
    try:
        p=cmd('docker','ps','--filter','label=com.docker.compose.project=autokom-logs',
              '--filter','label=com.docker.compose.service=loki','--format','{{.ID}}',check=False)
        q=cmd('docker','ps','--filter','label=com.docker.compose.project=autokom-logs',
              '--filter','label=com.docker.compose.service=alloy','--format','{{.ID}}',check=False)
    except RuntimeErrorSafe:
        return False
    return p.returncode == 0 and q.returncode == 0 and bool(p.stdout.strip() or q.stdout.strip())


def detected():
    native=active_native()
    docker=active_docker()
    if native and docker:return 'mixed'
    if native:return 'systemd'
    if docker:return 'docker'
    try:
        value=json.loads(STATE.read_text())['runtime']
        if value in ('systemd','docker'): return value
    except (FileNotFoundError,OSError,KeyError,ValueError,TypeError):pass
    return 'none'


def native_ready():
    if not all(cmd('systemctl','is-active','--quiet',unit,check=False).returncode==0 for unit in UNITS):
        return False
    from logging_health import http_status
    return all(http_status(name)['ok'] for name in UNITS)


def runtime_ready(backend, runtime):
    if runtime=='systemd':return backend=='loki' and native_ready() and not active_docker()
    from logging_stack import ready
    return ready(backend) and not active_native()


def report():
    choice=detected()
    print('  ◈ AUTOKOM / MODE D’EXÉCUTION LOKI + ALLOY')
    print('  › Mode détecté : '+choice)
    print('  › Docker Compose : '+('actif' if active_docker() else 'inactif'))
    print('  › Services systemd : '+('actifs' if active_native() else 'inactifs'))
    if choice=='mixed': print('  ✗ Deux modes simultanément actifs : corriger le conflit avant installation.')
    print('  › Ports privés : Loki 127.0.0.1:3100 ; Alloy 127.0.0.1:12345')


def plan(target):
    if target not in ('docker','systemd'): raise RuntimeErrorSafe('Mode invalide: '+target)
    current=detected()
    print(f'  AUTOKOM LOGS / PLAN — {current} → {target} (sans modification)')
    if current=='mixed': print('  ✗ État mixte : intervention nécessaire')
    elif current==target: print('  ✓ Mode sélectionné ; contrôle de santé et réconciliation requis')
    elif current=='none': print('  + Installer Loki/Alloy en mode '+target)
    else:
        print('  1. Préparer configuration et binaires du nouveau mode')
        print('  2. Sauvegarder la configuration et toutes les données Loki existantes')
        print('  3. Arrêter uniquement l’ancien couple Loki/Alloy')
        print('  4. Transférer les données, démarrer le nouveau couple et vérifier les endpoints')
        print('  5. Vérifier une vraie ingestion journald → Alloy → Loki')
        print('  6. Supprimer les composants de l’ancien mode après preuve de conformité')
        print('  ! Interruption temporaire des logs possible pendant la bascule')
    print('  › Aucun autre conteneur Docker, service Jenkins ou Grafana n’est ciblé.')


def secure_save(path, data, mode=0o644):
    if path.is_symlink():raise RuntimeErrorSafe('Lien symbolique refusé : '+str(path))
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,temp=tempfile.mkstemp(dir=path.parent,prefix='.autokom-')
    try:
        with os.fdopen(fd,'w') as f:f.write(data)
        os.chmod(temp,mode)
        os.replace(temp,path)
    finally:
        if os.path.exists(temp):os.unlink(temp)


def save_state(mode):
    secure_save(STATE,json.dumps({'schema':1,'runtime':mode},indent=2)+'\n',0o644)


def verify_canary():
    from logs_canary import probe
    if probe(wait=45) != 0:
        raise RuntimeErrorSafe('Sonde E2E en échec ; ancien mode conservé et retour arrière nécessaire')


def require_loki_only(backend):
    if backend != 'loki':
        raise RuntimeErrorSafe('Mode systemd : Loki+Alloy seulement. OpenSearch/dual reste en mode Docker, sans migration destructive implicite.')
    if shutil.which('docker'):
        p=cmd('docker','ps','-a','--filter','label=com.docker.compose.project=autokom-logs',
              '--filter','label=com.docker.compose.service=opensearch','--format','{{.ID}}',check=False)
        if p.returncode==0 and p.stdout.strip():
            raise RuntimeErrorSafe('OpenSearch actif dans le projet Compose : transition systemd bloquée ; aucune suppression automatique.')


def new_backup():
    """Reserve a unique backup directory without ever reusing an old snapshot.

    Multiple independent stages (migration and legacy-config relocation) can
    request backups during the same second. A timestamp alone is not unique;
    do not let FileExistsError abort an otherwise safe recovery and NEVER
    delete or overwrite the existing backup to make room.
    """
    if BACKUP_ROOT.is_symlink():
        raise RuntimeErrorSafe('Répertoire de sauvegardes symbolique refusé : ' + str(BACKUP_ROOT))
    BACKUP_ROOT.mkdir(parents=True, exist_ok=True, mode=0o700)
    if not BACKUP_ROOT.is_dir() or BACKUP_ROOT.is_symlink():
        raise RuntimeErrorSafe('Répertoire de sauvegardes invalide : ' + str(BACKUP_ROOT))
    os.chmod(BACKUP_ROOT, 0o700)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    # mkdir is atomic: concurrent AUTOKOM processes cannot select one path.
    for sequence in range(10000):
        name = stamp if sequence == 0 else f'{stamp}-{sequence:04d}'
        destination = BACKUP_ROOT / name
        try:
            destination.mkdir(mode=0o700)
        except FileExistsError:
            continue
        return destination
    raise RuntimeErrorSafe('Impossible de réserver une sauvegarde Loki unique : '+stamp)


def backup_configs(target):
    for directory in ('/etc/autokom/logs','/etc/autokom/logs-native', '/etc/autokom-logging'):
        source=Path(directory)
        if source.is_dir() and not source.is_symlink():
            shutil.copytree(source,target/source.name,symlinks=True)
    return target


def docker_container(service):
    p=cmd('docker','ps','-a','--filter','label=com.docker.compose.project=autokom-logs',
          '--filter',f'label=com.docker.compose.service={service}','--format','{{.ID}}')
    ids=p.stdout.splitlines()
    if len(ids)!=1:raise RuntimeErrorSafe('Conteneur Compose manquant ou ambigü : '+service)
    return ids[0]


def docker_compose(*args):
    from logging_stack import docker
    return cmd(*docker('--profile','loki',*args),timeout=600)


def native_files():
    from logging_stack import yaml_loki, alloy_config
    loki=yaml_loki().replace('http_listen_port: 3100','http_listen_address: 127.0.0.1\n  http_listen_port: 3100').replace('/loki/',str(DATA)+'/').replace('path_prefix: /loki',f'path_prefix: {DATA}')
    alloy=alloy_config('loki').replace('http://loki:3100/loki/api/v1/push','http://127.0.0.1:3100/loki/api/v1/push')
    return {'loki.yaml':loki,'config.alloy':alloy}


def install_vendor_packages():
    # APT packages are official; never use the Ubuntu `loki` package implicitly.
    key=Path('/etc/apt/keyrings/grafana.asc')
    if not key.exists():
        key.parent.mkdir(parents=True,exist_ok=True)
        cmd('curl','-fsSL','--output',str(key),'https://apt.grafana.com/gpg-full.key')
        os.chmod(key,0o644)
    source=Path('/etc/apt/sources.list.d/grafana.list')
    expected='deb [signed-by=/etc/apt/keyrings/grafana.asc] https://apt.grafana.com stable main\n'
    if source.exists() and source.read_text()!=expected:
        raise RuntimeErrorSafe('Dépôt Grafana existant modifié : intervention nécessaire')
    if not source.exists():secure_save(source,expected)
    # Stay on the same exact versions as the Docker stack during TSDB migration.
    # Some package repositories drop historical versions; abort rather than
    # silently upgrade on an irreversible storage-format transition.
    cmd('apt-get','update',timeout=240)
    pins={}
    for package,wanted in (('loki','3.7.0'),('alloy','1.11.0')):
        versions=cmd('apt-cache','madison',package).stdout
        found=[line.split('|')[1].strip() for line in versions.splitlines()
               if len(line.split('|'))>=3 and
               (line.split('|')[1].strip()==wanted or line.split('|')[1].strip().startswith(wanted+'-'))]
        if not found:
            raise RuntimeErrorSafe(f'Version {package}={wanted} introuvable dans le dépôt Grafana ; aucune bascule engagée')
        pins[package]=found[0]
    # Runtime mask prevents post-install starting native daemons before cutover.
    for unit in UNITS:
        cmd('systemctl','mask','--runtime',unit+'.service',check=False)
    try:
        cmd('apt-get','install','-y','--no-install-recommends',
            'loki='+pins['loki'],'alloy='+pins['alloy'],timeout=600)
    finally:
        for unit in UNITS:cmd('systemctl','unmask','--runtime',unit+'.service',check=False)
    if not shutil.which('loki') or not shutil.which('alloy'):
        raise RuntimeErrorSafe('Binaires Loki/Alloy officiels introuvables après installation')


def prepare_native_data():
    """Copy legacy Loki data to a traversable service directory, never erase it.

    /var/lib/autokom belongs to the Django service (0750); the dedicated Loki
    account cannot traverse that parent even when it owns its own child.
    """
    if DATA.is_symlink() or LEGACY_DATA.is_symlink():
        raise RuntimeErrorSafe('Stockage Loki symbolique : migration refusée')
    if DATA.exists() and not DATA.is_dir():
        raise RuntimeErrorSafe('Chemin de données Loki non répertoire')
    if LEGACY_DATA.exists():
        if not LEGACY_DATA.is_dir():
            raise RuntimeErrorSafe('Ancien stockage Loki non répertoire')
        if any(LEGACY_DATA.iterdir()):
            if DATA.exists() and any(DATA.iterdir()):
                raise RuntimeErrorSafe('Ancien et nouveau stockages Loki non vides : fusion interdite')
            # Loki must not ingest filesystem links from the old private tree.
            for folder, directories, files in os.walk(LEGACY_DATA, followlinks=False):
                for name in directories + files:
                    if (Path(folder) / name).is_symlink():
                        raise RuntimeErrorSafe('Lien symbolique dans les anciennes données Loki')
            shutil.copytree(LEGACY_DATA, DATA, dirs_exist_ok=True)
            print('  ✓ Données Loki recopiées sans effacer l’ancien répertoire privé')
    DATA.mkdir(parents=True, exist_ok=True, mode=0o750)
    os.chmod(DATA, 0o750)


def prepare_native():
    # State is still root-only. Services only read the non-secret configuration
    # from /etc/autokom-logging, never /etc/autokom (0750 root:root).
    NATIVE.mkdir(parents=True, exist_ok=True, mode=0o755)
    if CONFIG_DIR.is_symlink() or (CONFIG_DIR.exists() and not CONFIG_DIR.is_dir()):
        raise RuntimeErrorSafe('Répertoire de configuration Loki symbolique/invalide')
    CONFIG_DIR.mkdir(parents=True, exist_ok=True, mode=0o755)
    if CONFIG_DIR.stat().st_mode & 0o022:
        raise RuntimeErrorSafe('Configuration Loki modifiable par un utilisateur non autorisé')
    CONFIG_DIR.chmod(0o755)
    prepare_native_data()
    expected = native_files()
    marker = (NATIVE / '.autokom-installed').is_file()
    # Validate ALL managed paths before changing any file; an operator-edited
    # path must not leave the installation half-upgraded. Save legacy files
    # once per repair, not once per config (which caused duplicate snapshots).
    to_create = []
    legacy_backup_needed = False
    for key, content in expected.items():
        previous = NATIVE / key
        managed = CONFIG_DIR / key
        if previous.is_symlink() or managed.is_symlink():
            raise RuntimeErrorSafe('Fichier de configuration Loki symbolique interdit')
        if previous.exists():
            old = previous.read_text()
            allowed = (content, content.replace(str(DATA), str(LEGACY_DATA)))
            if old not in allowed:
                raise RuntimeErrorSafe('Ancien fichier natif modifié manuellement : '+str(previous))
        if managed.exists() and managed.read_text() != content:
            raise RuntimeErrorSafe('Configuration Loki non gérée : '+str(managed))
        if not managed.exists():
            to_create.append((managed, content))
            legacy_backup_needed |= previous.exists() and marker
    if legacy_backup_needed:
        location = new_backup()
        backup_configs(location)
        print('  ✓ Sauvegarde unique des anciennes configurations Loki : '+str(location))
    for managed, content in to_create:
        secure_save(managed, content)
    if cmd('id', '-u', 'autokom-loki', check=False).returncode != 0:
        cmd('useradd', '--system', '--home-dir', str(DATA), '--shell', '/usr/sbin/nologin', 'autokom-loki')
    # Package service usually runs as `alloy`; ensure reading journald & nginx.
    if cmd('id','-u','alloy',check=False).returncode!=0:
        raise RuntimeErrorSafe('Utilisateur alloy manquant après installation APT')
    groups=[]
    for group in ('adm','systemd-journal','docker'):
        if cmd('getent','group',group,check=False).returncode==0:groups.append(group)
    if groups:cmd('usermod','-aG',','.join(groups),'alloy')
    print('  ! Le groupe docker donne un accès très privilégié : une politique de socket-proxy reste recommandée.')
    native_loki=CONFIG_DIR/'loki.yaml'
    native_alloy=CONFIG_DIR/'config.alloy'
    unit_loki=Path('/etc/systemd/system/loki.service.d/90-autokom.conf')
    unit_alloy=Path('/etc/systemd/system/alloy.service.d/90-autokom.conf')
    loki_binary=shutil.which('loki')
    secure_save(unit_loki,'[Service]\nExecStart=\nExecStart='+loki_binary+' -config.file='+str(native_loki)+'\nUser=autokom-loki\nGroup=autokom-loki\nNoNewPrivileges=true\n')
    secure_save(NATIVE/'alloy.env','CONFIG_FILE="'+str(native_alloy)+'"\nCUSTOM_ARGS="--server.http.listen-addr=127.0.0.1:12345"\nSTORAGE_DIRECTORY="/var/lib/alloy/data"\n')
    secure_save(unit_alloy,'[Service]\nEnvironmentFile=\nEnvironmentFile='+str(NATIVE/'alloy.env')+'\nNoNewPrivileges=true\n')
    cmd('systemctl','daemon-reload')
    cmd(shutil.which('alloy'),'validate',str(native_alloy),timeout=90)
    secure_save(NATIVE/'.autokom-installed','loki=3.7.0\nalloy=1.11.0\n',0o600)
    print('  ✓ Loki/Alloy : configurations et stockage accessibles aux comptes dédiés')


def validate_native_permissions():
    """Check that the daemon identities can traverse their real paths.

    `alloy validate` under root alone is not proof that systemd's alloy user
    can read its config. Likewise Loki needs access to its data directory.
    """
    for account, path, needed in (
        ('autokom-loki', CONFIG_DIR / 'loki.yaml', 'r'),
        ('autokom-loki', DATA, 'w'),
        ('alloy', CONFIG_DIR / 'config.alloy', 'r'),
    ):
        result = cmd('runuser', '-u', account, '--', 'test', '-'+needed,
                     str(path), check=False)
        if result.returncode:
            raise RuntimeErrorSafe(
                f'Droits {account} insuffisants sur {path} ; services non relancés')


def chown_loki(root):
    import pwd
    id=pwd.getpwnam('autokom-loki')
    for folder,dirs,files in os.walk(root,followlinks=False):
        os.chown(folder,id.pw_uid,id.pw_gid)
        for name in dirs+files:
            path=Path(folder)/name
            if not path.is_symlink():os.chown(path,id.pw_uid,id.pw_gid)


def retire_managed_docker_configs():
    # Only uninstall generated files matching AUTOKOM's manifest; never touch
    # an operator-modified file. Originals are already inside the backup.
    from logging_stack import STATE_DIR, MANIFEST, read_manifest, sha
    manifest=read_manifest()
    for name in ('compose.yaml','config.alloy','loki.yaml','pipelines.yaml'):
        path=STATE_DIR/name
        if path.is_symlink():raise RuntimeErrorSafe('Fichier Docker symbolique : retrait refusé')
        if path.exists() and manifest.get(name)!=sha(path.read_text()):
            raise RuntimeErrorSafe('Configuration Docker non gérée : retrait manuel nécessaire : '+str(path))
    for name in ('compose.yaml','config.alloy','loki.yaml','pipelines.yaml',MANIFEST,'.env'):
        path=STATE_DIR/name
        if path.is_file() and not path.is_symlink():path.unlink()


def docker_volume_path():
    from logging_stack import STATE_DIR
    volume='autokom-logs_loki-data'
    out=cmd('docker','volume','inspect',volume,'--format','{{json .}}')
    record=json.loads(out.stdout)
    if record.get('Driver')!='local' or (record.get('Labels') or {}).get('com.docker.compose.project')!='autokom-logs':
        raise RuntimeErrorSafe('Volume Loki non local/non géré : copie automatique interdite')
    mount=Path(record['Mountpoint'])
    root=cmd('docker','info','--format','{{.DockerRootDir}}').stdout.strip()
    if not mount.is_dir() or mount.is_symlink() or not mount.resolve().is_relative_to(Path(root).resolve()):
        raise RuntimeErrorSafe('Chemin volume Docker invalide')
    return mount


def native_journal_hints():
    """Categorize startup errors without exposing log lines or credentials.

    The operator should not have to collect basic service crash diagnostics
    after each automated recovery. Raw journals may contain private headers or
    environment values: never echo them in the unattended recovery summary.
    """
    categories = (
        ('permission denied', 'permissions ou sandbox systemd'),
        ('access denied', 'permissions ou sandbox systemd'),
        ('read-only file system', 'stockage en lecture seule'),
        ('address already in use', 'collision de port local'),
        ('unknown flag', 'option de démarrage non prise en charge'),
        ('flag provided but not defined', 'option de démarrage non prise en charge'),
        ('failed to parse', 'fichier de configuration invalide'),
        ('error parsing', 'fichier de configuration invalide'),
        ('failed to load config', 'fichier de configuration inaccessible ou invalide'),
        ('no such file or directory', 'chemin de configuration ou de stockage absent'),
        ('out of memory', 'mémoire insuffisante'),
    )
    findings = []
    for unit in UNITS:
        result = cmd('journalctl', '-u', unit+'.service', '-n', '60',
                     '--no-pager', '-o', 'cat', check=False, timeout=10)
        if result.returncode:
            continue
        lines = result.stdout.lower().splitlines()
        for line in reversed(lines):
            match = next((label for pattern, label in categories if pattern in line), None)
            if match:
                findings.append(f'{unit}: {match}')
                break
    return '; '.join(findings)


def native_failure_summary():
    """Expose actionable unit states without copying journals or credentials to stdout."""
    from logging_health import http_status
    sections = []
    for unit in UNITS:
        state = cmd('systemctl', 'show', unit+'.service',
                    '-p', 'ActiveState', '-p', 'SubState', '-p', 'ExecMainStatus',
                    '--no-pager', check=False)
        pairs = {}
        for line in state.stdout.splitlines():
            if '=' in line:
                key, value = line.split('=', 1)
                if key in ('ActiveState', 'SubState', 'ExecMainStatus'):
                    pairs[key] = value
        detail = http_status(unit)['detail']
        sections.append(f"{unit}: {pairs.get('ActiveState','unknown')}/"
                        f"{pairs.get('SubState','unknown')}, exit={pairs.get('ExecMainStatus','?')}, "
                        f"API={detail}")
    return '; '.join(sections)


def wait_ready():
    """Wait for verified endpoints; one safe retry of failed *managed* units."""
    from logging_health import http_status
    from tool_banner import Activity
    until = time.monotonic() + 60
    retried = set()
    with Activity('Attente de disponibilité Loki et Alloy'):
        while time.monotonic() < until:
            if all(http_status(item)['ok'] for item in UNITS):
                return
            for unit in UNITS:
                status = cmd('systemctl', 'is-failed', '--quiet', unit,
                             check=False).returncode
                if status == 0 and unit not in retried:
                    # Retrying is limited to a single explicitly managed unit.
                    if not (NATIVE / '.autokom-installed').is_file():
                        break
                    retried.add(unit)
                    cmd('systemctl', 'reset-failed', unit, check=False)
                    cmd('systemctl', 'start', unit, check=False)
            time.sleep(3)
    diagnosis = native_journal_hints()
    raise RuntimeErrorSafe('Loki/Alloy non prêts après démarrage et reprise ciblée : '
                           + native_failure_summary()
                           + (' ; indices des journaux : '+diagnosis if diagnosis else '')
                           + '. Logs précis : journalctl -u loki -u alloy -n 80 --no-pager')


def require_confirm(source,target):
    from menu import pick
    try:
        selected=pick(f'AUTOKOM · Confirmer {source} → {target}',
           ['Confirmer la migration, puis le retrait de l’ancien mode'],default=1,
           cancel_label='Annuler sans modifier l’infrastructure')
    except RuntimeError as exc:
        raise RuntimeErrorSafe('Migration destructive : confirmation interactive TTY obligatoire') from exc
    if selected!=1:raise RuntimeErrorSafe('Migration annulée par l’administrateur')


def migrate_to_native(backend):
    require_loki_only(backend)
    previous=detected()
    if previous=='mixed':raise RuntimeErrorSafe('Modes Docker et systemd simultanés : intervention manuelle')
    if previous=='systemd':
        if not native_ready():
            if not (NATIVE/'.autokom-installed').is_file():
                raise RuntimeErrorSafe('Services systemd non gérés : réparation refusée')
            # Repair native config and data permissions before retrying units.
            prepare_native()
            chown_loki(DATA)
            validate_native_permissions()
            for unit in UNITS:
                cmd('systemctl', 'reset-failed', unit, check=False)
                cmd('systemctl', 'enable', '--now', unit, check=False)
            wait_ready()
        from logging_stack import provision_grafana
        from logging_monitoring import apply as apply_monitoring
        changed=provision_grafana();apply_monitoring()
        from logging_stack import sync_grafana_after_install
        sync_grafana_after_install(changed)
        return
    # Pre-existing unmanaged packages must not be overwritten by AUTOKOM.
    if previous!='systemd' and (shutil.which('loki') or shutil.which('alloy')) and             not (NATIVE/'.autokom-installed').is_file():
        raise RuntimeErrorSafe('Installation native préexistante non gérée : refus de modifier les services')
    require_confirm(previous,'systemd') if previous!='none' else None
    if previous=='docker':
        from logging_stack import validate_managed, read_manifest
        validate_managed(read_manifest())
    backup=new_backup()
    backup_configs(backup)
    # A failed first installation has already downloaded and pinned packages.
    # Avoid APT work on every repair attempt when binaries and AUTOKOM marker exist.
    if not ((NATIVE/'.autokom-installed').is_file()
            and shutil.which('loki') and shutil.which('alloy')):
        install_vendor_packages()
    prepare_native()
    if previous=='docker':
        # Stop before copying Loki TSDB to avoid inconsistent filesystem state.
        docker_compose('stop','alloy','loki')
        try:
            old=docker_container('loki')
            store=backup/'loki-data'
            store.mkdir()
            cmd('docker','cp',old+':/loki/.',str(store),timeout=600)
            if any(DATA.iterdir()):raise RuntimeErrorSafe('Données natives déjà présentes : fusion automatique interdite')
            from tool_banner import Activity
            with Activity('Transfert sécurisé des données Loki'):
                shutil.copytree(store,DATA,dirs_exist_ok=True)
        except Exception:
            docker_compose('up','-d','--no-build','alloy','loki')
            raise
    try:
        chown_loki(DATA)
        validate_native_permissions()
        for unit in UNITS:cmd('systemctl','enable','--now',unit)
        wait_ready()
        verify_canary()
    except Exception:
        for unit in UNITS:cmd('systemctl','disable','--now',unit,check=False)
        if previous=='docker':docker_compose('up','-d','--no-build','alloy','loki')
        raise
    save_state('systemd')
    if previous=='docker':
        docker_compose('rm','-s','-f','alloy','loki')
        remaining_volumes=[]
        for volume in ('autokom-logs_loki-data','autokom-logs_alloy-data'):
            removed=cmd('docker','volume','rm',volume,check=False)
            if removed.returncode: remaining_volumes.append(volume)
        from logging_stack import IMAGES
        for item in ('loki','alloy'):
            cmd('docker','image','rm',IMAGES[item],check=False)
        retire_managed_docker_configs()
        if remaining_volumes:
            raise RuntimeErrorSafe('Mode natif vérifié, mais nettoyage Docker incomplet : '+', '.join(remaining_volumes)+' ; ne pas déclarer la migration terminée')
        print('  ✓ Ancien couple Loki/Alloy Docker retiré ; autres conteneurs inchangés')
    from logging_stack import provision_grafana
    from logging_monitoring import apply as apply_monitoring
    changed=provision_grafana();apply_monitoring()
    from logging_stack import sync_grafana_after_install
    sync_grafana_after_install(changed)
    print('  ✓ Loki/Alloy natifs validés ; sauvegarde conservée : '+str(backup))


def migrate_to_docker(backend):
    from logging_stack import apply_docker
    if backend!='loki':raise RuntimeErrorSafe('Migration systemd vers Docker : backend loki seulement')
    previous=detected()
    if previous=='mixed':raise RuntimeErrorSafe('Modes concurrents détectés : intervention nécessaire')
    if previous=='docker':return apply_docker(backend)
    if previous=='none':return apply_docker(backend)
    if not (NATIVE/'.autokom-installed').is_file():
        raise RuntimeErrorSafe('Services natifs non gérés par AUTOKOM : purge automatique interdite')
    require_confirm(previous,'docker')
    backup=new_backup()
    backup_configs(backup)
    from logging_stack import install_files, validate_alloy, docker, profile_args
    validate_alloy(backend)
    install_files(backend)
    cmd(*docker(*profile_args(backend),'config','-q'))
    # Create stopped target containers and local named volumes before copying.
    cmd(*docker(*profile_args(backend),'create','--no-build','loki','alloy'),timeout=600)
    volume=docker_volume_path()
    if any(volume.iterdir()):raise RuntimeErrorSafe('Volume Docker préexistant non vide : écrasement interdit')
    for unit in UNITS:cmd('systemctl','stop',unit)
    try:
        if DATA.is_dir():
            from tool_banner import Activity
            with Activity('Sauvegarde et copie des données Loki'):
                shutil.copytree(DATA,backup/'loki-data',symlinks=False)
                shutil.copytree(DATA,volume,dirs_exist_ok=True)
        for folder,dirs,files in os.walk(volume,followlinks=False):
            os.chown(folder,10001,10001)
            for name in dirs+files:
                path=Path(folder)/name
                if not path.is_symlink():os.chown(path,10001,10001)
        cmd(*docker(*profile_args(backend),'up','-d','--no-build','loki','alloy'),timeout=600)
        wait_ready();verify_canary()
    except Exception:
        cmd(*docker(*profile_args(backend),'stop','loki','alloy'),check=False)
        for unit in UNITS:cmd('systemctl','start',unit,check=False)
        raise
    save_state('docker')
    # Purge only if AUTOKOM's managed native overrides prove it owned install.
    managed=((NATIVE/'.autokom-installed').exists() and
             Path('/etc/systemd/system/loki.service.d/90-autokom.conf').exists() and
             Path('/etc/systemd/system/alloy.service.d/90-autokom.conf').exists())
    for unit in UNITS:cmd('systemctl','disable','--now',unit,check=False)
    if managed:
        cmd('apt-get','purge','-y','loki','alloy',timeout=600)
        for unit in UNITS:
            Path('/etc/systemd/system/'+unit+'.service.d/90-autokom.conf').unlink(missing_ok=True)
        cmd('systemctl','daemon-reload')
        if NATIVE.is_dir():shutil.rmtree(NATIVE)
        if DATA.is_dir():shutil.rmtree(DATA)
    else:
        print('  ! Paquets natifs non identifiés comme gérés : arrêtés mais purge manuelle nécessaire')
    from logging_stack import provision_grafana
    from logging_monitoring import apply as apply_monitoring
    changed=provision_grafana();apply_monitoring()
    from logging_stack import sync_grafana_after_install
    sync_grafana_after_install(changed)
    print('  ✓ Couple Docker actif, ancien couple systemd désactivé ; sauvegarde : '+str(backup))


def apply(target,backend):
    if os.geteuid()!=0:raise RuntimeErrorSafe('sudo requis pour changer de mode')
    if target not in ('docker','systemd'):raise RuntimeErrorSafe('Mode inconnu')
    current=detected()
    if current=='mixed':raise RuntimeErrorSafe('Conflit : deux modes actifs')
    if target=='systemd':return migrate_to_native(backend)
    return migrate_to_docker(backend)
