data "google_compute_network" "existing" {
  project = var.project_id
  name    = var.network_name
}

data "google_compute_subnetwork" "existing" {
  project = var.project_id
  region  = var.region
  name    = var.subnetwork_name
}

# Identite sans permission implicite : les roles applicatifs se donnent explicitement.
resource "google_service_account" "web" {
  project      = var.project_id
  account_id   = "${var.name_prefix}-vm"
  display_name = "AUTOKOM regional MIG web instances"
}

resource "google_compute_instance_template" "web" {
  project      = var.project_id
  name_prefix  = "${var.name_prefix}-tpl-"
  description  = "Only AUTOKOM web workers; NOT the main AUTOKOM orchestrator."
  machine_type = var.machine_type
  tags         = ["${var.name_prefix}-backend"]
  labels       = var.labels

  disk {
    boot         = true
    auto_delete  = true
    source_image = var.boot_image
    disk_size_gb = var.boot_disk_size_gb
    disk_type    = "pd-balanced"
  }

  network_interface {
    subnetwork = data.google_compute_subnetwork.existing.self_link
    dynamic "access_config" {
      for_each = var.assign_external_ip ? [1] : []
      content {}
    }
  }

  service_account {
    email  = google_service_account.web.email
    scopes = ["https://www.googleapis.com/auth/cloud-platform"]
  }

  # Ne jamais placer des secrets dans metadata_startup_script.
  metadata_startup_script = var.bootstrap_mode == "validation" ? templatefile("${path.module}/files/validation-startup.sh.tftpl", {
    backend_port      = var.backend_port
    health_check_path = var.health_check_path
  }) : var.bootstrap_mode == "worker" && var.enable_app_delivery ? templatefile("${path.module}/files/worker-startup-delivery.sh.tftpl", {
    worker_settings = jsonencode({
      project_id          = var.project_id
      region              = var.region
      artifact_repository = var.artifact_repository
      state_bucket        = google_storage_bucket.app_state[0].name
      health_path         = var.health_check_path
      health_port         = 18080
    })
    health_check_path = var.health_check_path
    health_source     = file("${path.module}/files/worker-delivery-health.py")
    probe_source      = file("${path.module}/files/worker-probe.py")
    agent_source      = file("${path.module}/files/worker-agent.py")
  }) : var.bootstrap_mode == "worker" ? templatefile("${path.module}/files/worker-startup.sh.tftpl", {
    worker_settings = jsonencode({
      project_id             = var.project_id
      region                 = var.region
      artifact_repository    = var.artifact_repository
      health_path            = var.health_check_path
      health_port            = var.backend_port
    })
    health_source = file("${path.module}/files/worker-health.py")
    probe_source  = file("${path.module}/files/worker-probe.py")
  }) : var.application_startup_script

  lifecycle {
    create_before_destroy = true
    precondition {
      condition     = var.bootstrap_mode != "application" || (var.application_startup_script != null && trimspace(var.application_startup_script) != "")
      error_message = "bootstrap_mode=application exige application_startup_script, sans secret."
    }
  }
}

# La regle cible EXCLUSIVEMENT les nouveaux workers du MIG, et non l'orchestrateur.
resource "google_compute_firewall" "lb_to_web" {
  project       = var.project_id
  name          = "${var.name_prefix}-allow-lb"
  description   = "Google health checks et proxies globaux vers le backend web."
  network       = data.google_compute_network.existing.id
  direction     = "INGRESS"
  priority      = 1000
  source_ranges = ["35.191.0.0/16", "130.211.0.0/22"]
  target_tags   = ["${var.name_prefix}-backend"]

  allow {
    protocol = "tcp"
    ports    = [tostring(var.backend_port)]
  }
}

# Le reseau GCP default comporte des regles SSH et internes permissives.
# Cette regle ne cible QUE les nouvelles VM web du MIG par leur tag.
# Le trafic des proxies/health-checks passe par l'autorisation de priorite 1000 ci-dessus.
resource "google_compute_firewall" "deny_other_mig_ingress" {
  count         = var.restrict_mig_ingress ? 1 : 0
  project       = var.project_id
  name          = "${var.name_prefix}-deny-other-ingress"
  description   = "Defense en profondeur : aucune entree directe sur les nouvelles VM MIG."
  network       = data.google_compute_network.existing.id
  direction     = "INGRESS"
  priority      = 1100
  source_ranges = ["0.0.0.0/0"]
  target_tags   = ["${var.name_prefix}-backend"]

  deny {
    protocol = "all"
  }
}

resource "google_compute_health_check" "web" {
  project             = var.project_id
  name                = "${var.name_prefix}-health"
  check_interval_sec  = 10
  timeout_sec         = 5
  healthy_threshold   = 2
  unhealthy_threshold = 3

  http_health_check {
    port         = var.backend_port
    request_path = var.health_check_path
  }
}

resource "google_compute_region_instance_group_manager" "web" {
  project                   = var.project_id
  region                    = var.region
  name                      = "${var.name_prefix}-rmig"
  base_instance_name        = "${var.name_prefix}-web"
  distribution_policy_zones = var.zones
  target_size               = var.min_replicas
  deletion_policy           = "PREVENT"

  version {
    instance_template = google_compute_instance_template.web.self_link_unique
  }

  named_port {
    name = "http"
    port = var.backend_port
  }

  # Nouvelle generation du template : les VMs sont remplacees, jamais
  # redimensionnees en place. Garder les anciennes en service jusqu'a la
  # disponibilite des nouvelles (2 zones => surge minimal de deux VMs).
  update_policy {
    type                           = "PROACTIVE"
    minimal_action                 = "REPLACE"
    most_disruptive_allowed_action = "REPLACE"
    replacement_method             = "SUBSTITUTE"
    max_surge_fixed                = 2
    max_unavailable_fixed          = 0
    # min_ready_sec is beta-only; standard hashicorp/google rejects it.
    # MIG health checking still gates worker readiness during replacements.
  }

  # Les workers installent Docker au premier demarrage. Dans le contexte GCP
  # observe, les seuls telechargements apt ont dure plus de dix minutes.
  # La verification HTTP conserve son code 503 tant que la preparation echoue;
  # seule la fenetre initiale de l'autohealing est prolongee pour ces modes.
  auto_healing_policies {
    health_check      = google_compute_health_check.web.id
    initial_delay_sec = var.bootstrap_mode == "validation" ? 360 : var.worker_initial_delay_seconds
  }

  lifecycle {
    # L'Autoscaler, pas Terraform, gere la taille apres creation.
    ignore_changes  = [target_size]
    prevent_destroy = true
  }
  depends_on = [google_compute_firewall.lb_to_web, google_compute_firewall.deny_other_mig_ingress]
}

resource "google_compute_region_autoscaler" "web" {
  project = var.project_id
  region  = var.region
  name    = "${var.name_prefix}-autoscaler"
  target  = google_compute_region_instance_group_manager.web.id

  autoscaling_policy {
    min_replicas    = var.min_replicas
    max_replicas    = var.max_replicas
    cooldown_period = var.cooldown_seconds

    cpu_utilization {
      target = var.cpu_target
    }
    # Le controleur applicatif peut hausser temporairement minNumReplicas
    # pour une nouvelle application (independamment de la charge CPU).
    # L'autoscaler ne doit pas effacer immediatement cette reserve.
    scale_in_control {
      max_scaled_in_replicas { fixed = 1 }
      time_window_sec = 1800
    }
  }
  lifecycle {
    # Minima augmente/diminue au besoin par le controleur HA via API GCP.
    # Les autres parametres demeurent sous controle Terraform.
    ignore_changes = [autoscaling_policy[0].min_replicas]
    precondition {
      condition     = var.max_replicas >= var.min_replicas
      error_message = "max_replicas doit etre >= min_replicas."
    }
  }
}

# Sortie IPv4 facultative pour les VM sans IP publique du sous-reseau EXISTANT.
# Cloud NAT ne fournit aucun acces entrant et ne change ni MIG ni instance template.
# ATTENTION : ce NAT couvre toutes les VM sans IP externe du sous-reseau primaire
# de la region, pas uniquement les VM du MIG ; couts GCP additionnels.
resource "google_compute_router" "worker_egress" {
  count   = var.enable_cloud_nat ? 1 : 0
  project = var.project_id
  region  = var.region
  name    = "${var.name_prefix}-router"
  network = data.google_compute_network.existing.id
}

resource "google_compute_router_nat" "worker_egress" {
  count                               = var.enable_cloud_nat ? 1 : 0
  project                             = var.project_id
  region                              = var.region
  name                                = "${var.name_prefix}-nat"
  router                              = google_compute_router.worker_egress[0].name
  nat_ip_allocate_option              = "AUTO_ONLY"
  source_subnetwork_ip_ranges_to_nat  = "LIST_OF_SUBNETWORKS"
  min_ports_per_vm                    = 64

  subnetwork {
    name                    = data.google_compute_subnetwork.existing.id
    source_ip_ranges_to_nat = ["PRIMARY_IP_RANGE"]
  }

  log_config {
    enable = true
    filter = "ERRORS_ONLY"
  }
}

# Global external Application Load Balancer (HTTP valide en premiere phase).
resource "google_compute_global_address" "lb" {
  project      = var.project_id
  name         = "${var.name_prefix}-lb-ip"
  address_type = "EXTERNAL"
  ip_version   = "IPV4"
  lifecycle {
    prevent_destroy = true
  }
}

resource "google_compute_backend_service" "web" {
  project               = var.project_id
  name                  = "${var.name_prefix}-backend"
  protocol              = "HTTP"
  port_name             = "http"
  load_balancing_scheme = "EXTERNAL_MANAGED"
  timeout_sec           = 30
  health_checks         = [google_compute_health_check.web.id]
  session_affinity      = "NONE"

  backend {
    group           = google_compute_region_instance_group_manager.web.instance_group
    balancing_mode  = "UTILIZATION"
    max_utilization = 0.8
  }
}

resource "google_compute_url_map" "web" {
  # The authenticated AUTOKOM application reconciler exclusively owns host/path rules.
  # Terraform continues to own default_service and the URL map's lifecycle.
  lifecycle { ignore_changes = [host_rule, path_matcher] }
  project         = var.project_id
  name            = "${var.name_prefix}-map"
  default_service = google_compute_backend_service.web.id
}

resource "google_compute_target_http_proxy" "web" {
  project = var.project_id
  name    = "${var.name_prefix}-http-proxy"
  url_map = google_compute_url_map.web.id
}

resource "google_compute_global_forwarding_rule" "http" {
  project               = var.project_id
  name                  = "${var.name_prefix}-http"
  load_balancing_scheme = "EXTERNAL_MANAGED"
  ip_protocol           = "TCP"
  port_range            = "80"
  ip_address            = google_compute_global_address.lb.id
  target                = google_compute_target_http_proxy.web.id
}

# HTTPS classique, avec validation via le load balancer, pour un seul domaine.
resource "google_compute_managed_ssl_certificate" "web" {
  count   = var.enable_https && var.https_dns_zone == null ? 1 : 0
  project = var.project_id
  name    = "${var.name_prefix}-cert"
  managed {
    domains = [var.domain_name]
  }
  lifecycle {
    precondition {
      condition     = var.domain_name != null && trimspace(var.domain_name == null ? "" : var.domain_name) != ""
      error_message = "enable_https=true exige un nom de domaine DNS valide dans domain_name."
    }
  }
}

resource "google_compute_target_https_proxy" "web" {
  count            = var.enable_https ? 1 : 0
  project          = var.project_id
  name             = "${var.name_prefix}-https-proxy"
  url_map          = google_compute_url_map.web.id
  ssl_certificates = var.https_dns_zone == null ? [google_compute_managed_ssl_certificate.web[0].id] : null
  certificate_map  = var.https_dns_zone == null ? null : "//certificatemanager.googleapis.com/${google_certificate_manager_certificate_map.web[0].id}"

  # Ensure the wildcard entry exists before attaching the map.
  depends_on = [google_certificate_manager_certificate_map_entry.web_wildcard]
}

resource "google_compute_global_forwarding_rule" "https" {
  count                 = var.enable_https ? 1 : 0
  project               = var.project_id
  name                  = "${var.name_prefix}-https"
  load_balancing_scheme = "EXTERNAL_MANAGED"
  ip_protocol           = "TCP"
  port_range            = "443"
  ip_address            = google_compute_global_address.lb.id
  target                = google_compute_target_https_proxy.web[0].id
}

# Enabled explicitly after the delivery agent passes its local tests.
# The bucket is private, regional and versioned; no secrets go into manifests.
resource "google_storage_bucket" "app_state" {
  count                       = var.enable_app_delivery ? 1 : 0
  project                     = var.project_id
  name                        = "${var.project_id}-${var.name_prefix}-state"
  location                    = var.region
  storage_class               = "STANDARD"
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = false
  versioning { enabled = true }
}

resource "google_storage_bucket_iam_member" "worker_state_reader" {
  count  = var.enable_app_delivery ? 1 : 0
  bucket = google_storage_bucket.app_state[0].name
  role   = "roles/storage.objectViewer"
  member = "serviceAccount:${google_service_account.web.email}"
}

resource "google_storage_bucket_iam_member" "controller_state_writer" {
  count  = var.enable_app_delivery ? 1 : 0
  bucket = google_storage_bucket.app_state[0].name
  role   = "roles/storage.objectAdmin"
  member = "serviceAccount:autokom-terraform@${var.project_id}.iam.gserviceaccount.com"
}
